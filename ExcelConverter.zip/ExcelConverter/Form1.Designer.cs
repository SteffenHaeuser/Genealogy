﻿
namespace ExcelConverter
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labFilename = new System.Windows.Forms.Label();
            this.btnConvert = new System.Windows.Forms.Button();
            this.txtFilename = new System.Windows.Forms.TextBox();
            this.labStatus = new System.Windows.Forms.Label();
            this.labStatusValue = new System.Windows.Forms.Label();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.labOutput = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labFilename
            // 
            this.labFilename.AutoSize = true;
            this.labFilename.Location = new System.Drawing.Point(36, 35);
            this.labFilename.Name = "labFilename";
            this.labFilename.Size = new System.Drawing.Size(110, 20);
            this.labFilename.TabIndex = 0;
            this.labFilename.Text = "Input Filename:";
            // 
            // btnConvert
            // 
            this.btnConvert.Location = new System.Drawing.Point(531, 31);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(94, 29);
            this.btnConvert.TabIndex = 1;
            this.btnConvert.Text = "Convert";
            this.btnConvert.UseVisualStyleBackColor = true;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // txtFilename
            // 
            this.txtFilename.Location = new System.Drawing.Point(175, 32);
            this.txtFilename.Name = "txtFilename";
            this.txtFilename.Size = new System.Drawing.Size(331, 27);
            this.txtFilename.TabIndex = 2;
            this.txtFilename.Text = "C:\\Users\\shaeuser\\ExcelConverter\\6474.txt";
            // 
            // labStatus
            // 
            this.labStatus.AutoSize = true;
            this.labStatus.Location = new System.Drawing.Point(36, 124);
            this.labStatus.Name = "labStatus";
            this.labStatus.Size = new System.Drawing.Size(0, 20);
            this.labStatus.TabIndex = 3;
            // 
            // labStatusValue
            // 
            this.labStatusValue.AutoSize = true;
            this.labStatusValue.Location = new System.Drawing.Point(175, 124);
            this.labStatusValue.Name = "labStatusValue";
            this.labStatusValue.Size = new System.Drawing.Size(29, 20);
            this.labStatusValue.TabIndex = 4;
            this.labStatusValue.Text = "OK";
            // 
            // txtOutput
            // 
            this.txtOutput.Location = new System.Drawing.Point(175, 74);
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.Size = new System.Drawing.Size(331, 27);
            this.txtOutput.TabIndex = 6;
            this.txtOutput.Text = "C:\\Users\\shaeuser\\ExcelConverter\\6474.xlsx";
            // 
            // labOutput
            // 
            this.labOutput.AutoSize = true;
            this.labOutput.Location = new System.Drawing.Point(36, 77);
            this.labOutput.Name = "labOutput";
            this.labOutput.Size = new System.Drawing.Size(122, 20);
            this.labOutput.TabIndex = 5;
            this.labOutput.Text = "Output Filename:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1329, 177);
            this.Controls.Add(this.txtOutput);
            this.Controls.Add(this.labOutput);
            this.Controls.Add(this.labStatusValue);
            this.Controls.Add(this.labStatus);
            this.Controls.Add(this.txtFilename);
            this.Controls.Add(this.btnConvert);
            this.Controls.Add(this.labFilename);
            this.Name = "Form1";
            this.Text = "Converter";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labFilename;
        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.TextBox txtFilename;
        private System.Windows.Forms.Label labStatus;
        private System.Windows.Forms.Label labStatusValue;
        private System.Windows.Forms.TextBox txtOutput;
        private System.Windows.Forms.Label labOutput;
    }
}

