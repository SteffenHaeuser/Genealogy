﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;

namespace ExcelConverter
{
    public partial class Form1 : Form
    {
        Excel.Application excelData;

        public Form1()
        {
            InitializeComponent();
            labStatus.Text = "Status:";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        void DisplayInExcel()
        {
            var excelApp = excelData;
            string kronland;
            string staat;
            string buchtyp;
            string ort;
            string ortdetail;
            string konfession;
            string buch;
            string year;
            string temp;
            int idx;
            string isdp;
            int num;

            // Add a new Excel workbook.
            var book = excelApp.Workbooks.Add();
            Excel._Worksheet sheet = book.Sheets[1];
            excelApp.Visible = true;
            sheet.Cells[1, 1].Value = "KRONLAND";
            return;
            excelApp.Range["A1"].Value = "KRONLAND";
            excelApp.Range["B1"].Value = "Heutiger_Staat";
            excelApp.Range["C1"].Value = "BuchTyp";
            excelApp.Range["D1"].Value = "Ort_Matrikenführung";
            excelApp.Range["E1"].Value = "Ort_Detail";
            excelApp.Range["F1"].Value = "KONFESSION";
            excelApp.Range["G1"].Value = "Buch";
            excelApp.Range["H1"].Value = "xSeite";
            excelApp.Range["I1"].Value = "Geburtsdatum_Jahr";
            excelApp.Range["J1"].Value = "Geburtsdatum_Monat";
            excelApp.Range["K1"].Value = "Geburtsdatum_Tag";
            excelApp.Range["L1"].Value = "Geburt_Ort";
            excelApp.Range["M1"].Value = "Geboren_V";
            excelApp.Range["N1"].Value = "Geboren_S";
            excelApp.Range["O1"].Value = "Vater_V";
            excelApp.Range["P1"].Value = "Vater_F";
            excelApp.Range["Q1"].Value = "Vater_B";
            excelApp.Range["R1"].Value = "Mutter_V";
            excelApp.Range["S1"].Value = "Mutter_F";
            excelApp.Range["T1"].Value = "Comment";
            excelApp.Range["AF1"].Value = "Zeuge 1_V";
            excelApp.Range["AG1"].Value = "Zeuge 1_F";
            excelApp.Range["AH1"].Value = "Zeuge 1_W";
            excelApp.Range["AI1"].Value = "Zeuge 1_B";
            excelApp.Range["AJ1"].Value = "Zeuge 2_V";
            excelApp.Range["AK1"].Value = "Zeuge 2_F";
            excelApp.Range["AL1"].Value = "Zeuge 2_W";
            excelApp.Range["AM1"].Value = "Zeuge 2_B";
            excelApp.Range["AN1"].Value = "Zeuge 3_V";
            excelApp.Range["AO1"].Value = "Zeuge 3_F";
            excelApp.Range["AP1"].Value = "Zeuge 3_W";
            excelApp.Range["AQ1"].Value = "Zeuge 3_B";
            excelApp.Range["AR1"].Value = "Zeuge 4_V";
            excelApp.Range["AS1"].Value = "Zeuge 4_F";
            excelApp.Range["AT1"].Value = "Zeuge 4_W";
            excelApp.Range["AU1"].Value = "Zeuge 4_B";
            num = 2;
            using (FileStream filestream = new FileStream(txtFilename.Text, FileMode.Open, FileAccess.Read))
            {
                using (StreamReader reader = new StreamReader(filestream, Encoding.Default))
                {
                    kronland = reader.ReadLine();
                    staat = reader.ReadLine();
                    buchtyp = reader.ReadLine();
                    ort = reader.ReadLine();
                    ortdetail = reader.ReadLine();
                    konfession = reader.ReadLine();
                    buch = reader.ReadLine();
                    year = "";
                    isdp = "";
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        if (line.Length == 0)
                        {
                            continue;
                        }
                        if ((line.Length.Equals(4)) && (line.Contains("DP") == false))
                        {
                            year = line;
                            continue;
                        }
                        if (line.StartsWith("DP"))
                        {
                            line = line.Substring(3);
                            isdp = line;
                            continue;
                        }
                        if (!line.Contains(","))
                        {
                            continue;
                        }
                        idx = line.IndexOf(",");
                        temp = line.Substring(0, idx);
                        if (temp.Contains(".") == true)
                        {
                            line = "#," + line;
                        }
                        excelApp.Range["A" + num].Value = kronland;
                        excelApp.Range["B" + num].Value = staat;
                        excelApp.Range["C" + num].Value = buchtyp;
                        excelApp.Range["D" + num].Value = ort;
                        excelApp.Range["E" + num].Value = ortdetail;
                        excelApp.Range["F" + num].Value = konfession;
                        excelApp.Range["G" + num].Value = buch;
                        excelApp.Range["I" + num].Value = year;
                        excelApp.Range["H" + num].Value = isdp;
                        if (line.Contains("####"))
                        {

                        }
                        else
                        {
                            excelApp.Range["L" + num].Value = line;
                            /*
                            excelApp.Range["L" + num].Value = GetOrt(line);
                            excelApp.Range["J" + num].Value = GetMonat(line);
                            excelApp.Range["K" + num].Value = GetTag(line);
                            excelApp.Range["M" + num].Value = GetVorname(line);
                            excelApp.Range["O" + num].Value = GetVaterVorname(line);
                            excelApp.Range["P" + num].Value = GetVaterNachname(line);
                            excelApp.Range["Q" + num].Value = GetBeruf(line);
                            excelApp.Range["R" + num].Value = GetMutterVorname(line);
                            excelApp.Range["S" + num].Value = "";
                            excelApp.Range["T" + num].Value = GetComment(line);
                            excelApp.Range["AF" + num].Value = GetZeuge1V(line);
                            excelApp.Range["AG" + num].Value = GetZeuge1F(line);
                            excelApp.Range["AH" + num].Value = GetZeuge1W(line);
                            excelApp.Range["AI" + num].Value = GetZeuge1B(line);
                            excelApp.Range["AJ" + num].Value = GetZeuge2V(line);
                            excelApp.Range["AK" + num].Value = GetZeuge2F(line);
                            excelApp.Range["AL" + num].Value = GetZeuge2W(line);
                            excelApp.Range["AM" + num].Value = GetZeuge2B(line);
                            excelApp.Range["AN" + num].Value = GetZeuge3V(line);
                            excelApp.Range["AO" + num].Value = GetZeuge3F(line);
                            excelApp.Range["AP" + num].Value = GetZeuge3W(line);
                            excelApp.Range["AQ" + num].Value = GetZeuge3B(line);
                            excelApp.Range["AR" + num].Value = GetZeuge4V(line);
                            excelApp.Range["AS" + num].Value = GetZeuge4F(line);
                            excelApp.Range["AT" + num].Value = GetZeuge4W(line);
                            excelApp.Range["AU" + num].Value = GetZeuge4B(line);*/
                        }
                        num++;
                        // if (num > 500) break;
                    }


                }
            }
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            if (txtOutput.Text.Length == 0) return;
            if (File.ReadAllText(txtFilename.Text) == null) return;

            Cursor.Current = Cursors.WaitCursor;
            Excel.Application xlApp = new Excel.Application();
            Excel.Workbook xlWorkbook = xlApp.Workbooks.Add();
            Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];
            Excel.Range xlRange = xlWorksheet.UsedRange;
            excelData = xlApp;


            //    xlWorksheet.Cells[1, 1] = "Bla";
            // xlWorksheet.Cells[2, 3] = "Bla3";
            // xlWorksheet.Cells[2, 5] = "Bla5";
            Marriage.ErrorString = "";
            labStatusValue.Text = "Converting ...";
            Marriage.DisplayInExcelMarry(excelData, txtFilename.Text, labStatusValue);
            if (Marriage.ErrorString != "") labStatusValue.Text = Marriage.ErrorString;
            else labStatusValue.Text = "Conversion Finished";
            xlApp.Visible = false;
            xlApp.UserControl = false;
            //xlWorkbook.Set
            //xlWorkbook.Save();
            xlWorkbook.SaveCopyAs(txtOutput.Text);


            //cleanup
            GC.Collect();
            GC.WaitForPendingFinalizers();

            //release com objects to fully kill excel process from running in the background
            Marshal.ReleaseComObject(xlRange);
            Marshal.ReleaseComObject(xlWorksheet);

            //close and release
            xlWorkbook.Close();
            Marshal.ReleaseComObject(xlWorkbook);

            //quit and release
            xlApp.Quit();
            Marshal.ReleaseComObject(xlApp);

            // Set cursor as default arrow
            Cursor.Current = Cursors.Default;
        }
    }
}
