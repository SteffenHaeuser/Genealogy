﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelConverter
{
    public class Common
    {
        public static object GetZeuge1V(string line)
        {
            string zeuge;
            string origLine = line;
            try
            {
                int idx = line.IndexOf("[");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf("]");
                if (idx == -1) return "";
                zeuge = line.Substring(0, idx);
                idx = zeuge.IndexOf("1:<");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 3);
                idx = zeuge.IndexOf("1>");
                if (idx == -1) return "";
                else zeuge = zeuge.Substring(0, idx);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                return zeuge.Substring(0, idx);
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetZeuge1V() with Line " + origLine;
                return "";
            }
        }

        public static object GetZeuge1F(string line)
        {
            string zeuge;
            string origLine = line;
            try
            {
                int idx = line.IndexOf("[");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf("]");
                if (idx == -1) return "";
                zeuge = line.Substring(0, idx);
                idx = zeuge.IndexOf("1:<");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 3);
                idx = zeuge.IndexOf("1>");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(0, idx);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 1);
                idx = zeuge.IndexOf(",");
                if (idx != -1)
                {
                    zeuge = zeuge.Substring(0, idx);
                }
                return zeuge;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetZeuge1F() with Line " + origLine;
                return "";
            }
        }

        public static object GetZeuge1W(string line)
        {
            string zeuge;
            string origLine = line;

            try
            {
                int idx = line.IndexOf("[");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf("]");
                if (idx == -1) return "";
                zeuge = line.Substring(0, idx);
                idx = zeuge.IndexOf("1:<");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 3);
                idx = zeuge.IndexOf("1>");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(0, idx);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 1);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                else
                {
                    zeuge = zeuge.Substring(idx + 1);
                }
                idx = zeuge.IndexOf(",");
                if (idx != -1)
                {
                    zeuge = zeuge.Substring(0, idx);
                }
                return zeuge;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetZeuge1W() with Line " + origLine;
                return "";
            }
        }

        public static object GetZeuge1B(string line)
        {
            string zeuge;
            string origLine = line;
            try
            {
                int idx = line.IndexOf("[");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf("]");
                if (idx == -1) return "";
                zeuge = line.Substring(0, idx);
                idx = zeuge.IndexOf("1:<");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 3);
                idx = zeuge.IndexOf("1>");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(0, idx);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 1);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                else
                {
                    zeuge = zeuge.Substring(idx + 1);
                }
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                else
                {
                    zeuge = zeuge.Substring(idx + 1);
                }
                return zeuge;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetZeuge1B() with Line " + origLine;
                return "";
            }
        }
        public static object GetZeuge2V(string line)
        {
            string zeuge;
            string origLine = line;

            try
            {
                int idx = line.IndexOf("[");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf("]");
                if (idx == -1) return "";
                zeuge = line.Substring(0, idx);
                idx = zeuge.IndexOf("2:<");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 3);
                idx = zeuge.IndexOf("2>");
                if (idx == -1) return "";
                else zeuge = zeuge.Substring(0, idx);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                return zeuge.Substring(0, idx);
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetZeuge2V() with Line " + origLine;
                return "";
            }
        }

        public static object GetZeuge2F(string line)
        {
            string zeuge;
            string origLine = line;

            try
            {
                int idx = line.IndexOf("[");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf("]");
                if (idx == -1) return "";
                zeuge = line.Substring(0, idx);
                idx = zeuge.IndexOf("2:<");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 3);
                idx = zeuge.IndexOf("2>");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(0, idx);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 1);
                idx = zeuge.IndexOf(",");
                if (idx != -1)
                {
                    zeuge = zeuge.Substring(0, idx);
                }
                return zeuge;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetZeuge2F() with Line " + origLine;
                return "";
            }
        }

        public static object GetZeuge2W(string line)
        {
            string zeuge;
            string origLine = line;

            try
            {
                int idx = line.IndexOf("[");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf("]");
                if (idx == -1) return "";
                zeuge = line.Substring(0, idx);
                idx = zeuge.IndexOf("2:<");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 3);
                idx = zeuge.IndexOf("2>");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(0, idx);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 1);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                else
                {
                    zeuge = zeuge.Substring(idx + 1);
                }
                idx = zeuge.IndexOf(",");
                if (idx != -1)
                {
                    zeuge = zeuge.Substring(0, idx);
                }
                return zeuge;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetZeuge2W() with Line " + origLine;
                return "";
            }
        }

        public static object GetZeuge2B(string line)
        {
            string zeuge;
            string origLine = line;

            try
            {
                int idx = line.IndexOf("[");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf("]");
                if (idx == -1) return "";
                zeuge = line.Substring(0, idx);
                idx = zeuge.IndexOf("2:<");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 3);
                idx = zeuge.IndexOf("2>");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(0, idx);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 1);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                else
                {
                    zeuge = zeuge.Substring(idx + 1);
                }
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                else
                {
                    zeuge = zeuge.Substring(idx + 1);
                }
                return zeuge;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetZeuge2B() with Line " + origLine;
                return "";
            }
        }

        public static object GetZeuge3V(string line)
        {
            string zeuge;
            string origLine = line;

            try
            {
                int idx = line.IndexOf("[");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf("]");
                if (idx == -1) return "";
                zeuge = line.Substring(0, idx);
                idx = zeuge.IndexOf("3:<");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 3);
                idx = zeuge.IndexOf("3>");
                if (idx == -1) return "";
                else zeuge = zeuge.Substring(0, idx);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                return zeuge.Substring(0, idx);
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetZeuge3V() with Line " + origLine;
                return "";
            }
        }

        public static object GetZeuge3F(string line)
        {
            string zeuge;
            string origLine = line;

            try
            {
                int idx = line.IndexOf("[");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf("]");
                if (idx == -1) return "";
                zeuge = line.Substring(0, idx);
                idx = zeuge.IndexOf("3:<");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 3);
                idx = zeuge.IndexOf("3>");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(0, idx);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 1);
                idx = zeuge.IndexOf(",");
                if (idx != -1)
                {
                    zeuge = zeuge.Substring(0, idx);
                }
                return zeuge;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetZeuge3F() with Line " + origLine;
                return "";
            }
        }

        public static object GetZeuge3W(string line)
        {
            string zeuge;
            string origLine = line;

            try
            {
                int idx = line.IndexOf("[");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf("]");
                if (idx == -1) return "";
                zeuge = line.Substring(0, idx);
                idx = zeuge.IndexOf("3:<");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 3);
                idx = zeuge.IndexOf("3>");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(0, idx);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 1);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                else
                {
                    zeuge = zeuge.Substring(idx + 1);
                }
                idx = zeuge.IndexOf(",");
                if (idx != -1)
                {
                    zeuge = zeuge.Substring(0, idx);
                }
                return zeuge;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetZeuge3W() with Line " + origLine;
                return "";
            }
        }

        public static object GetZeuge3B(string line)
        {
            string zeuge;
            string origLine = line;

            try
            {
                int idx = line.IndexOf("[");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf("]");
                if (idx == -1) return "";
                zeuge = line.Substring(0, idx);
                idx = zeuge.IndexOf("3:<");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 3);
                idx = zeuge.IndexOf("3>");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(0, idx);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 1);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                else
                {
                    zeuge = zeuge.Substring(idx + 1);
                }
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                else
                {
                    zeuge = zeuge.Substring(idx + 1);
                }
                return zeuge;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetZeuge3B() with Line " + origLine;
                return "";
            }
        }

        public static object GetZeuge4V(string line)
        {
            string zeuge;
            string origLine = line;

            try
            {
                int idx = line.IndexOf("[");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf("]");
                if (idx == -1) return "";
                zeuge = line.Substring(0, idx);
                idx = zeuge.IndexOf("4:<");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 3);
                idx = zeuge.IndexOf("4>");
                if (idx == -1) return "";
                else zeuge = zeuge.Substring(0, idx);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                return zeuge.Substring(0, idx);
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetZeuge4V() with Line " + origLine;
                return "";
            }
        }

        public static object GetZeuge4F(string line)
        {
            string zeuge;
            string origLine = line;

            try
            {
                int idx = line.IndexOf("[");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf("]");
                if (idx == -1) return "";
                zeuge = line.Substring(0, idx);
                idx = zeuge.IndexOf("4:<");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 3);
                idx = zeuge.IndexOf("4>");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(0, idx);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 1);
                idx = zeuge.IndexOf(",");
                if (idx != -1)
                {
                    zeuge = zeuge.Substring(0, idx);
                }
                return zeuge;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetZeuge4F() with Line " + origLine;
                return "";
            }
        }

        public static object GetZeuge4W(string line)
        {
            string zeuge;
            string origLine = line;

            try
            {
                int idx = line.IndexOf("[");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf("]");
                if (idx == -1) return "";
                zeuge = line.Substring(0, idx);
                idx = zeuge.IndexOf("4:<");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 3);
                idx = zeuge.IndexOf("4>");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(0, idx);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 1);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                else
                {
                    zeuge = zeuge.Substring(idx + 1);
                }
                idx = zeuge.IndexOf(",");
                if (idx != -1)
                {
                    zeuge = zeuge.Substring(0, idx);
                }
                return zeuge;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetZeuge4W() with Line " + origLine;
                return "";
            }
        }

        public static object GetZeuge4B(string line)
        {
            string zeuge;
            string origLine = line;

            try
            {
                int idx = line.IndexOf("[");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf("]");
                if (idx == -1) return "";
                zeuge = line.Substring(0, idx);
                idx = zeuge.IndexOf("4:<");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 3);
                idx = zeuge.IndexOf("4>");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(0, idx);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                zeuge = zeuge.Substring(idx + 1);
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                else
                {
                    zeuge = zeuge.Substring(idx + 1);
                }
                idx = zeuge.IndexOf(",");
                if (idx == -1) return "";
                else
                {
                    zeuge = zeuge.Substring(idx + 1);
                }
                return zeuge;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetZeuge4B() with Line " + origLine;
                return "";
            }
        }

        public static object GetTag(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(".");
                line = line.Substring(0, idx);
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetTag() with Line " + origLine;
                return "";
            }
            return line;
        }

        public static object GetMonat(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(".");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(0, idx);
                return line;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetMonat() with Line " + origLine;
                return "";
            }
        }

        public static object GetVorname(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(0, idx);
                return line;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetVorname() with Line " + origLine;
                return "";
            }
        }

        public static object GetVaterVorname(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(0, idx);
                return line;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetVaterVorname() with Line " + origLine;
                return "";
            }
        }
        public static object GetVaterNachname(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(0, idx);
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetVaterNachname() with Line " + origLine;
                return "";
            }
            return line;
        }
    }
}
