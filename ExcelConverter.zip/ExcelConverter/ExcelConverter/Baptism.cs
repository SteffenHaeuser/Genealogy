﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Windows.Forms;

namespace ExcelConverter
{
    public class Baptism
    {
        private static string GetOrt(string line)
        {
            string origLine = line;
            try
            {
                string line2 = "";
                int idx = line.IndexOf("(Beruf");
                if (idx != -1)
                {
                    line2 = line.Substring(idx + 6);
                    idx = line2.IndexOf(")");
                    line2 = line2.Substring(0, idx);
                    idx = line2.IndexOf(",");
                    if (idx == -1)
                    {
                        line2 = "";
                    }
                    else
                    {
                        idx = line2.IndexOf("#");
                        if (idx == -1) line2 = "";
                        else line2 = line2.Substring(idx);
                    }
                }
                idx = line.IndexOf("(#");
                if (idx != -1)
                {
                    if (!line.Contains("(#)"))
                    {
                        line2 = line.Substring(idx + 1);
                        idx = line2.IndexOf(")");
                        line2 = line2.Substring(0, idx);
                    }
                }
                idx = line.IndexOf(",");
                if (line2.Contains("#"))
                {
                    line2 = " " + line2;
                }
                string tmp = line.Substring(0, idx) + line2;
                return tmp;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetOrt() with Line " + origLine;
                return "";
            }
        }
        private static object GetBeruf(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf("Beruf ");
                if (idx == -1) return "";
                line = line.Substring(idx + 6);
                idx = line.IndexOf(")");
                line = line.Substring(0, idx);
                if (line.Contains(","))
                {
                    idx = line.IndexOf(",");
                    line = line.Substring(0, idx);
                }

                return line;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetBeruf() with Line " + origLine;
                return "";
            }
        }
        private static object GetMutterVorname(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf("U:");
                if (idx != -1)
                {
                    line = line.Substring(0, idx);
                    if (line.EndsWith(" ")) line = line.Substring(0, idx - 1);
                }
                idx = line.IndexOf("(");
                if (idx == -1) return line;
                line = line.Substring(0, idx);
                if (line.EndsWith(" ")) line = line.Substring(0, idx - 1);
                idx = line.IndexOf("U:");
                if (idx != -1)
                {
                    line = line.Substring(0, idx);
                    if (line.EndsWith(" ")) line = line.Substring(0, idx - 1);
                }
                return line;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetMutterVorname() with Line " + origLine;
                return "";
            }
        }
        private static object GetMutterNachname(string line)
        {
            string origLine = line;
            string temp;
            try
            {
                int idx = line.IndexOf("U:");
                if (idx == -1) return "";
                idx = line.IndexOf("U: Kind von ");
                if (idx == -1) return "";
                temp = "U: Kind von " + GetMutterVorname(line);
                idx = line.IndexOf(temp);
                if (idx == -1) return "";
                line = line.Substring(idx + temp.Length);
                if (line.StartsWith(" ")) line = line.Substring(1);
                return line;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetMutterNachname() with Line " + origLine;
                return "";
            }
        }
        private static object GetComment(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf("Beruf ");
                if (idx == -1)
                {
                    idx = line.IndexOf(",");
                    line = line.Substring(idx + 1);
                    idx = line.IndexOf(",");
                    line = line.Substring(idx + 1);
                    idx = line.IndexOf(",");
                    line = line.Substring(idx + 1);
                    idx = line.IndexOf(",");
                    line = line.Substring(idx + 1);
                    idx = line.IndexOf(",");
                    line = line.Substring(idx + 1);
                    idx = line.IndexOf("(");
                    if (idx == -1)
                    {
                        if (line.Contains("U:"))
                        {
                            idx = line.IndexOf("U:");
                            line = line.Substring(idx + 3);
                            string str = "";
                            if (!line.StartsWith("U:")) str = ", der Täufling ist ";
                            line = line.Replace("U:", str);
                            if (line.EndsWith(" ")) line = line.Substring(0, line.Length - 2);
                            if (line.StartsWith(" ")) line = line.Substring(1, line.Length - 1);
                            if (line.StartsWith("# ")) line = line.Substring(2);
                            if (line.StartsWith("Kind von ")) line = "";
                            return line;
                        }
                        return "";
                    }
                    line = line.Substring(idx);
                    if (line.Contains("("))
                    {
                        line = line.Replace("(", "");
                    }
                    if (line.Contains(")"))
                    {
                        line = line.Replace(")", "");
                    }
                    if (line.Contains(" U:"))
                    {
                        idx = line.IndexOf(" U:");
                        line = line.Substring(0, idx);
                    }
                    if (line.StartsWith("# ")) line = line.Substring(2);
                    return line;
                }
                idx = line.IndexOf(") ");
                if (idx == -1)
                {
                    return "";
                }
                line = line.Substring(idx + 1);
                if (line.Contains("("))
                {
                    line = line.Replace("(", "");
                }
                if (line.Contains(")"))
                {
                    line = line.Replace(")", "");
                }
                if (line.StartsWith(" ")) line = line.Substring(1, line.Length - 1);
                if (line.Contains("U:"))
                {
                    string str = "";
                    if (!line.StartsWith("U:")) str = ", der Täufling ist ";
                    line = line.Replace("U:", str);
                    if (line.EndsWith(" ")) line = line.Substring(0, line.Length - 2);
                    if (line.StartsWith(" ")) line = line.Substring(1, line.Length - 1);
                }
                if (line.StartsWith("# ")) line = line.Substring(2);
                return line;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetComment() with Line " + origLine;
                return "";
            }
        }

        public static void DisplayInExcelBaptisms(Excel.Application excelData, String inputFilename, Label labStatusValue)
        {
            var excelApp = excelData;
            string kronland;
            string staat;
            string buchtyp;
            string ort;
            string ortdetail;
            string konfession;
            string buch;
            string genealogist;
            string year;
            string temp;
            int idx;
            string isdp;
            int num;

            var sheet = excelData.Workbooks[1].Sheets[1];
            sheet.Cells[1, 1].Value = "KRONLAND";
            sheet.Cells[1, 2].Value = "Heutiger_Staat";
            sheet.Cells[1, 3].Value = "BuchTyp";
            sheet.Cells[1, 4].Value = "Ort_Matrikenführung";
            sheet.Cells[1, 5].Value = "Ort_Detail";
            sheet.Cells[1, 6].Value = "KONFESSION";
            sheet.Cells[1, 7].Value = "Buch";
            sheet.Cells[1, 8].Value = "xSeite";
            sheet.Cells[1, 9].Value = "Geburtsdatum_Jahr";
            sheet.Cells[1, 10].Value = "Geburtsdatum_Monat";
            sheet.Cells[1, 11].Value = "Geburtsdatum_Tag";
            sheet.Cells[1, 12].Value = "Geburt_Ort";
            sheet.Cells[1, 13].Value = "Geboren_V";
            sheet.Cells[1, 14].Value = "Geboren_S";
            sheet.Cells[1, 15].Value = "Vater_V";
            sheet.Cells[1, 16].Value = "Vater_F";
            sheet.Cells[1, 17].Value = "Vater_B";
            sheet.Cells[1, 18].Value = "Mutter_V";
            sheet.Cells[1, 19].Value = "Mutter_F";
            sheet.Cells[1, 20].Value = "Comment";
            sheet.Cells[1, 21].Value = "Zeuge 1_V";
            sheet.Cells[1, 22].Value = "Zeuge 1_F";
            sheet.Cells[1, 23].Value = "Zeuge 1_W";
            sheet.Cells[1, 24].Value = "Zeuge 1_B";
            sheet.Cells[1, 25].Value = "Zeuge 2_V";
            sheet.Cells[1, 26].Value = "Zeuge 2_F";
            sheet.Cells[1, 27].Value = "Zeuge 2_W";
            sheet.Cells[1, 28].Value = "Zeuge 2_B";
            sheet.Cells[1, 29].Value = "Zeuge 3_V";
            sheet.Cells[1, 30].Value = "Zeuge 3_F";
            sheet.Cells[1, 31].Value = "Zeuge 3_W";
            sheet.Cells[1, 32].Value = "Zeuge 3_B";
            sheet.Cells[1, 33].Value = "Zeuge 4_V";
            sheet.Cells[1, 34].Value = "Zeuge 4_F";
            sheet.Cells[1, 35].Value = "Zeuge 4_W";
            sheet.Cells[1, 36].Value = "Zeuge 4_B";
            sheet.Cells[1, 37].Value = "Einsender";
            sheet.Cells[1, 38].Value = "URL";
            num = 2;
            using (FileStream filestream = new FileStream(inputFilename, FileMode.Open, FileAccess.Read))
            {
                using (StreamReader reader = new StreamReader(filestream, Encoding.Default))
                {
                    kronland = reader.ReadLine();
                    staat = reader.ReadLine();
                    buchtyp = reader.ReadLine();
                    ort = reader.ReadLine();
                    ortdetail = reader.ReadLine();
                    konfession = reader.ReadLine();
                    buch = reader.ReadLine();
                    genealogist = reader.ReadLine();
                    year = "";
                    isdp = "";
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        if (line.Length == 0)
                        {
                            continue;
                        }
                        if ((line.Length.Equals(4)) && (line.Contains("DP") == false))
                        {
                            year = line;
                            continue;
                        }
                        if (line.StartsWith("DP"))
                        {
                            line = line.Substring(3);
                            isdp = line;
                            continue;
                        }
                        if (!line.Contains(","))
                        {
                            continue;
                        }
                        idx = line.IndexOf(",");
                        temp = line.Substring(0, idx);
                        if (temp.Contains(".") == true)
                        {
                            line = "#," + line;
                        }
                        sheet.Cells[num, 1].Value = kronland;
                        sheet.Cells[num, 2].Value = staat;
                        sheet.Cells[num, 3].Value = buchtyp;
                        sheet.Cells[num, 4].Value = ort;
                        sheet.Cells[num, 5].Value = ortdetail;
                        sheet.Cells[num, 6].Value = konfession;
                        sheet.Cells[num, 7].Value = buch;
                        sheet.Cells[num, 9].Value = year;
                        sheet.Cells[num, 8].Value = isdp;
                        if (line.Contains("####"))
                        {

                        }
                        else
                        {
                            sheet.Cells[num, 10].Value = Common.GetMonat(line);
                            sheet.Cells[num, 11].Value = Common.GetTag(line);
                            sheet.Cells[num, 12].Value = Baptism.GetOrt(line);
                            sheet.Cells[num, 13].Value = Common.GetVorname(line);
                            sheet.Cells[num, 15].Value = Common.GetVaterVorname(line);
                            sheet.Cells[num, 16].Value = Common.GetVaterNachname(line);
                            sheet.Cells[num, 17].Value = Baptism.GetBeruf(line);
                            sheet.Cells[num, 18].Value = Baptism.GetMutterVorname(line);
                            sheet.Cells[num, 19].Value = Baptism.GetMutterNachname(line);
                            sheet.Cells[num, 20].Value = Baptism.GetComment(line);
                            sheet.Cells[num, 21].Value = Common.GetZeuge1V(line);
                            sheet.Cells[num, 22].Value = Common.GetZeuge1F(line);
                            sheet.Cells[num, 23].Value = Common.GetZeuge1W(line);
                            sheet.Cells[num, 24].Value = Common.GetZeuge1B(line);
                            sheet.Cells[num, 25].Value = Common.GetZeuge2V(line);
                            sheet.Cells[num, 26].Value = Common.GetZeuge2F(line);
                            sheet.Cells[num, 27].Value = Common.GetZeuge2W(line);
                            sheet.Cells[num, 28].Value = Common.GetZeuge2B(line);
                            sheet.Cells[num, 29].Value = Common.GetZeuge3V(line);
                            sheet.Cells[num, 30].Value = Common.GetZeuge3F(line);
                            sheet.Cells[num, 31].Value = Common.GetZeuge3W(line);
                            sheet.Cells[num, 32].Value = Common.GetZeuge3B(line);
                            sheet.Cells[num, 33].Value = Common.GetZeuge4V(line);
                            sheet.Cells[num, 34].Value = Common.GetZeuge4F(line);
                            sheet.Cells[num, 35].Value = Common.GetZeuge4W(line);
                            sheet.Cells[num, 36].Value = Common.GetZeuge4B(line);
                            sheet.Cells[num, 37].Value = genealogist;
                            sheet.Cells[num, 38].Value = Marriage.GetURL(line);
                        }
                        num++;
                        if (Marriage.ErrorString.Length == 0)
                        {
                            labStatusValue.Text = "Converting [" + num + "] ...";
                        }
                        else
                        {
                            labStatusValue.Text = Marriage.ErrorString;
                            break;
                        }
                        // if (num > 500) break;
                    }


                }
            }
        }
    }
}
