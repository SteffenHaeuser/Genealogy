﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Windows.Forms;

namespace ExcelConverter
{
    public class Marriage
    {
        static public string ErrorString = "";
        static private object GetBrautVorname(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(0, idx);
                return line;
            }
            catch
            {
                ErrorString = "Exception in GetBrautVorname() with Line " + origLine;
                return "";
            }
        }
        private static bool IsWidower(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                if (idx == -1) return false;
                line = line.Substring(idx + 1);
                if (line.StartsWith("W,")) return true;
                if (line.StartsWith("W ")) return true;
                return false;
            }
            catch
            {
                ErrorString = "Exception in IsWidower() with Line " + origLine;
                return false;
            }
        }
        private static bool IsGroomUnmarried(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                if (idx == -1) return false;
                line = line.Substring(idx + 1);
                if (line.StartsWith("J,")) return true;
                if (line.StartsWith("J ")) return true;
                return false;
            }
            catch
            {
                ErrorString = "Exception in IsGroomUnmarried() with Line " + origLine;
                return false;
            }
        }
        private static bool IsWidow(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                if (idx == -1) return false;
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                if (idx == -1) return false;
                line = line.Substring(idx + 1);
                if (line.StartsWith("W ")) return true;
                return false;
            }
            catch
            {
                ErrorString = "Exception in IsWidow() with Line " + origLine;
                return false;
            }
        }
        private static bool IsBrideUnmarried(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                if (idx == -1) return false;
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                if (idx == -1) return false;
                line = line.Substring(idx + 1);
                if (line.StartsWith("J ")) return true;
                return false;
            }
            catch
            {
                ErrorString = "Exception in IsBrideUnmarried() with Line " + origLine;
                return false;
            }
        }
        private static object GetBrautVaterVorname(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(0, idx);
                return line;
            }
            catch
            {
                ErrorString = "Exception in GetBrautVaterVorname() with Line " + origLine;
                return "";
            }
        }
        private static object GetBrautVaterNachname(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf("[");
                if (idx!=-1)
                {
                    line = line.Substring(0, idx);
                }
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                if (idx == -1)
                {
                    idx = line.IndexOf(" (");
                    if (idx == -1) return line;
                    line = line.Substring(0, idx);
                    idx = line.IndexOf(" [");
                    if (idx == -1) return line;
                    line = line.Substring(0, idx);
                    return line;
                }
                line = line.Substring(0, idx);
                idx = line.IndexOf(" (");
                if (idx == -1)
                {
                    idx = line.IndexOf(" [");
                    if (idx == -1) return line;
                    line = line.Substring(0, idx);
                    return line;
                }
                line = line.Substring(0, idx);
                idx = line.IndexOf(" [");
                if (idx == -1) return line;
                line = line.Substring(0, idx);
                return line;
            }
            catch
            {
                ErrorString = "Exception in GetBrautVaterNachname() with Line " + origLine;
                return "";
            }
        }
        private static object GetBrautOrt(string line)
        {
            string bck = line;
            try
            {
                int idx;
                if (bck.Contains("Ort des Bräutigams nicht angegeben"))
                {
                    idx = line.IndexOf(",");
                    line = line.Substring(0, idx);
                    if (line.Contains(" und ") == false) return line;
                    idx = line.IndexOf(" und ");
                    line = line.Substring(0, idx);

                    return line;
                }
                idx = line.IndexOf(",");
                line = line.Substring(0, idx);
                if (line.Contains(" und ") == false) return "";
                idx = line.IndexOf(" und ");
                line = line.Substring(idx + 4);
                return line;
            }
            catch
            {
                ErrorString = "Exception in GetBrautOrt() with Line " + bck;
                return "";
            }
        }
        private static dynamic GetHochzeitsOrt(string line)
        {
            string bck = line;
            try
            {
                if (bck.Contains("Ort des Bräutigams nicht angegeben"))
                {
                    return "";
                }
                int idx = line.IndexOf(",");
                line = line.Substring(0, idx);
                if (line.Contains(" und ") == false) return line;
                idx = line.IndexOf(" und ");
                line = line.Substring(0, idx);
                return line;
            }
            catch
            {
                ErrorString = "Exception in GetHochzeitsOrt() with Line " + bck;
                return "";
            }
        }
        private static object GetMarryComment(string line)
        {
            string comment;
            string temp;
            string origLine = line;

            try
            {
                int idx = line.IndexOf("[");
                if (idx!=-1)
                {
                    line = line.Substring(0, idx);
                }
                idx = line.IndexOf("(");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf(")");
                if (idx == -1) return "";
                comment = line.Substring(0, idx);
                idx = comment.IndexOf("Berufe ");
                if (idx == -1) return comment;
                temp = line.Substring(idx + 7);
                idx = temp.IndexOf("/");
                if (idx == -1) return comment;
                temp = temp.Substring(idx + 1);
                idx = temp.IndexOf(",");
                if (idx == -1) return "";
                temp = temp.Substring(idx + 1);
                if (temp.StartsWith(" ")) temp = temp.Substring(1);
                idx = temp.IndexOf("Der Vater des Bräutigams war ");
                if (idx == -1)
                {
                    idx = temp.IndexOf(")");
                    if (idx != -1) temp = temp.Substring(0, idx);
                    return temp;
                }
                idx = temp.IndexOf(",");
                if (idx == -1) return "";
                temp = temp.Substring(idx + 1);
                if (temp.StartsWith(" ")) temp = temp.Substring(1);
                idx = temp.IndexOf(")");
                if (idx != -1) temp = temp.Substring(0, idx);
                return temp;
            }
            catch
            {
                ErrorString = "Exception in GetMarryComment() with Line " + origLine;
                return "";
            }
        }
        private static object GetGroomBeruf(string line)
        {
            string beruf;
            string origLine = line;
            try
            {
                int idx = line.IndexOf("(");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf(")");
                if (idx == -1) return "";

                beruf = line.Substring(0, idx);
                idx = line.IndexOf("Berufe ");
                if (idx == -1) return "";
                beruf = beruf.Substring(idx + 7);
                idx = beruf.IndexOf("/");
                if (idx == -1) return "";
                beruf = beruf.Substring(0, idx);
                idx = beruf.IndexOf("Der Vater des Bräutigams war ");
                if (idx == -1) return beruf;
                beruf = beruf.Substring(idx + 29);
                idx = beruf.IndexOf(",");
                if (idx == -1) return "";
                beruf = beruf.Substring(idx + 1);
                if (beruf.StartsWith(" ")) beruf = beruf.Substring(1);
                return beruf;
            }
            catch
            {
                ErrorString = "Exception in GetGroomBeruf() with Line " + origLine;
                return "";
            }
        }

        private static object GetGroomFatherBeruf(string line)
        {
            string beruf;
            string origLine = line;
            try
            {
                int idx = line.IndexOf("Der Vater des Bräutigams war ");
                if (idx == -1) return "";
                beruf = line.Substring(idx + 29);
                idx = beruf.IndexOf(")");
                if (idx == -1) return "";
                beruf = beruf.Substring(0, idx);

                return beruf;
            }
            catch
            {
                ErrorString = "Exception in GetGroomFatherBeruf() with Line " + origLine;
                return "";
            }
        }

        private static object GetBrideFatherBeruf(string line)
        {
            string beruf;
            string origLine = line;
            try
            {
                int idx = line.IndexOf("(");
                if (idx == -1) return "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf(")");
                if (idx == -1) return "";

                beruf = line.Substring(0, idx);
                idx = line.IndexOf("Berufe ");
                if (idx == -1) return "";
                beruf = beruf.Substring(idx + 7);
                idx = beruf.IndexOf("/");
                if (idx == -1) return "";
                beruf = beruf.Substring(idx + 1);
                idx = beruf.IndexOf(",");
                if (idx != -1) beruf = beruf.Substring(0, idx);

                return beruf;
            }
            catch
            {
                ErrorString = "Exception in GetBrideFatherBeruf() with Line " + origLine;
                return "";
            }
        }
        static public object GetURL(string line)
        {
            string origLine = line;

            try
            {
                int idx = line.IndexOf("<!");
                if (idx == -1) return "";
                line = line.Substring(idx + 2);
                idx = line.IndexOf("!>");
                if (idx == -1) return "";
                return line.Substring(0, idx);
            }
            catch
            {
                ErrorString = "Exception in GetURL() with Line " + origLine;
                return "";
            }
        }
        static public void DisplayInExcelMarry(Excel.Application excelData, String inputFilename, Label labStatusValue)
        {
            var excelApp = excelData;
            string kronland;
            string staat;
            string buchtyp;
            string ort;
            string ortdetail;
            string konfession;
            string buch;
            string genealogist;
            string year;
            string isdp;
            int num;

            var sheet = excelData.Workbooks[1].Sheets[1];
            sheet.Cells[1, 1].Value = "KRONLAND";
            sheet.Cells[1, 2].Value = "Heutiger_Staat";
            sheet.Cells[1, 3].Value = "BuchTyp";
            sheet.Cells[1, 4].Value = "Ort_Matrikenführung";
            sheet.Cells[1, 5].Value = "Ort_Detail";
            sheet.Cells[1, 6].Value = "KONFESSION";
            sheet.Cells[1, 7].Value = "BUCH";
            sheet.Cells[1, 8].Value = "xseite";
            sheet.Cells[1, 9].Value = "Heiratsdatum_Jahr";
            sheet.Cells[1, 10].Value = "Heiratsdatum_Monat";
            sheet.Cells[1, 11].Value = "Heiratsdatum_Tag";
            sheet.Cells[1, 12].Value = "Bräutigam_W";
            sheet.Cells[1, 13].Value = "Bräutigam_V";
            sheet.Cells[1, 14].Value = "Bräutigam_F";
            sheet.Cells[1, 15].Value = "Bräutigam_S";
            sheet.Cells[1, 16].Value = "Bräutigamvater_V";
            sheet.Cells[1, 17].Value = "Bräutigamvater_F";
            sheet.Cells[1, 18].Value = "Braut_V";
            sheet.Cells[1, 19].Value = "Braut_VEV";
            sheet.Cells[1, 20].Value = "Braut_VEN";
            sheet.Cells[1, 21].Value = "Braut_S";
            sheet.Cells[1, 22].Value = "Brautvater_V";
            sheet.Cells[1, 23].Value = "Brautvater_F";
            sheet.Cells[1, 24].Value = "Sonstiges";
            sheet.Cells[1, 25].Value = "URL";
            sheet.Cells[1, 26].Value = "Einsender";
            sheet.Cells[1, 27].Value = "Abgabedatum";
            sheet.Cells[1, 28].Value = "Erfassungsmethode";
            sheet.Cells[1, 29].Value = "Erfassungsinhalt";
            sheet.Cells[1, 30].Value = "Auskunft";
            sheet.Cells[1, 31].Value = "Braut_W";
            sheet.Cells[1, 32].Value = "Zeuge 1_V";
            sheet.Cells[1, 33].Value = "Zeuge 1_F";
            sheet.Cells[1, 34].Value = "Zeuge 1_W";
            sheet.Cells[1, 35].Value = "Zeuge 1_B";
            sheet.Cells[1, 36].Value = "Zeuge 2_V";
            sheet.Cells[1, 37].Value = "Zeuge 2_F";
            sheet.Cells[1, 38].Value = "Zeuge 2_W";
            sheet.Cells[1, 39].Value = "Zeuge 2_B";
            sheet.Cells[1, 40].Value = "Zeuge 3_V";
            sheet.Cells[1, 41].Value = "Zeuge 3_F";
            sheet.Cells[1, 42].Value = "Zeuge 3_W";
            sheet.Cells[1, 43].Value = "Zeuge 3_B";
            sheet.Cells[1, 44].Value = "Zeuge 4_V";
            sheet.Cells[1, 45].Value = "Zeuge 4_F";
            sheet.Cells[1, 46].Value = "Zeuge 4_W";
            sheet.Cells[1, 47].Value = "Zeuge 4_B";
            sheet.Cells[1, 48].Value = "BRÄUTIGAM_B";
            sheet.Cells[1, 49].Value = "BRAUTVATER_B";
            sheet.Cells[1, 50].Value = "BRÄUTIGAMVATER_B";

            num = 2;
            using (FileStream filestream = new FileStream(inputFilename, FileMode.Open, FileAccess.Read))
            {
                using (StreamReader reader = new StreamReader(filestream, Encoding.Default))
                {
                    kronland = reader.ReadLine();
                    staat = reader.ReadLine();
                    buchtyp = reader.ReadLine();
                    ort = reader.ReadLine();
                    ortdetail = reader.ReadLine();
                    konfession = reader.ReadLine();
                    buch = reader.ReadLine();
                    genealogist = reader.ReadLine();
                    year = "";
                    isdp = "";
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        if (line.Length == 0)
                        {
                            continue;
                        }
                        if (line.Equals(" "))
                        {
                            continue;
                        }
                        if ((line.Length.Equals(4)) && (line.Contains("DP") == false))
                        {
                            year = line;
                            continue;
                        }
                        if (line.StartsWith("DP"))
                        {
                            line = line.Substring(3);
                            isdp = line;
                            continue;
                        }
                        sheet.Cells[num, 1].Value = kronland;
                        sheet.Cells[num, 2].Value = staat;
                        sheet.Cells[num, 3].Value = buchtyp;
                        sheet.Cells[num, 4].Value = ort;
                        sheet.Cells[num, 5].Value = ortdetail;
                        sheet.Cells[num, 6].Value = konfession;
                        sheet.Cells[num, 7].Value = buch;
                        sheet.Cells[num, 8].Value = isdp;
                        sheet.Cells[num, 9].Value = year;
                        sheet.Cells[num, 10].Value = Common.GetMonat(line);
                        sheet.Cells[num, 11].Value = Common.GetTag(line);
                        sheet.Cells[num, 13].Value = Common.GetVorname(line);
                        sheet.Cells[num, 14].Value = Common.GetVaterNachname(line);
                        sheet.Cells[num, 15].Value = "";
                        sheet.Cells[num, 16].Value = Common.GetVaterVorname(line);
                        sheet.Cells[num, 17].Value = Common.GetVaterNachname(line);
                        sheet.Cells[num, 18].Value = GetBrautVorname(line);
                        if (Marriage.IsWidow(line))
                        {
                            sheet.Cells[num, 19].Value = Marriage.GetBrautVaterVorname(line);
                            sheet.Cells[num, 20].Value = Marriage.GetBrautVaterNachname(line);
                            sheet.Cells[num, 21].Value = "Witwe";
                            if (sheet.Cells[num, 20].Value.Equals("W"))
                            {
                                Marriage.ErrorString = "Error in Line: " + line;
                            }
                            else if (sheet.Cells[num, 20].Value.Equals("J"))
                            {
                                Marriage.ErrorString = "Error in Line: " + line;
                            }
                        }
                        else if (Marriage.IsBrideUnmarried(line))
                        {
                            sheet.Cells[num, 22].Value = Marriage.GetBrautVaterVorname(line);
                            sheet.Cells[num, 23].Value = Marriage.GetBrautVaterNachname(line);
                            if (sheet.Cells[num, 23].Value.Equals("W"))
                            {
                                Marriage.ErrorString = "Error in Line: " + line;
                            }
                            else if (sheet.Cells[num, 23].Value.Equals("J"))
                            {
                                Marriage.ErrorString = "Error in Line: " + line;
                            }
                            if (IsBrideUnmarried(line))
                            {
                                sheet.Cells[num, 21].Value = "Ledig";
                            }
                        }
                        else
                        {
                            sheet.Cells[num, 22].Value = "";
                            sheet.Cells[num, 23].Value = Marriage.GetBrautVaterNachname(line);
                        }
                        if (Marriage.IsWidower(line))
                        {
                            sheet.Cells[num, 15].Value = "Witwer";
                        }
                        else if (Marriage.IsGroomUnmarried(line))
                        {
                            sheet.Cells[num, 15].Value = "Ledig";
                        }
                        sheet.Cells[num, 12].Value = Marriage.GetHochzeitsOrt(line);
                        sheet.Cells[num, 31].Value = GetBrautOrt(line);
                        sheet.Cells[num, 24].Value = GetMarryComment(line);
                        sheet.Cells[num, 25].Value = GetURL(line);
                        sheet.Cells[num, 32].Value = Common.GetZeuge1V(line);
                        sheet.Cells[num, 33].Value = Common.GetZeuge1F(line);
                        sheet.Cells[num, 34].Value = Common.GetZeuge1W(line);
                        sheet.Cells[num, 35].Value = Common.GetZeuge1B(line);
                        sheet.Cells[num, 36].Value = Common.GetZeuge2V(line);
                        sheet.Cells[num, 37].Value = Common.GetZeuge2F(line);
                        sheet.Cells[num, 38].Value = Common.GetZeuge2W(line);
                        sheet.Cells[num, 39].Value = Common.GetZeuge2B(line);
                        sheet.Cells[num, 40].Value = Common.GetZeuge3V(line);
                        sheet.Cells[num, 41].Value = Common.GetZeuge3F(line);
                        sheet.Cells[num, 42].Value = Common.GetZeuge3W(line);
                        sheet.Cells[num, 43].Value = Common.GetZeuge3B(line);
                        sheet.Cells[num, 44].Value = Common.GetZeuge4V(line);
                        sheet.Cells[num, 45].Value = Common.GetZeuge4F(line);
                        sheet.Cells[num, 46].Value = Common.GetZeuge4W(line);
                        sheet.Cells[num, 47].Value = Common.GetZeuge4B(line);
                        sheet.Cells[num, 26].Value = genealogist;
                        sheet.Cells[num, 27].Value = DateTime.Today.ToString();
                        sheet.Cells[num, 28].Value = "2";
                        sheet.Cells[num, 29].Value = "TEIL";
                        sheet.Cells[num, 30].Value = "O";
                        sheet.Cells[num, 48].Value = GetGroomBeruf(line);
                        sheet.Cells[num, 49].Value = GetGroomFatherBeruf(line);
                        sheet.Cells[num, 50].Value = GetBrideFatherBeruf(line);

                        num++;
                        if (ErrorString.Length == 0)
                        {
                            labStatusValue.Text = "Converting [" + num + "] ...";
                        }
                        else
                        {
                            labStatusValue.Text = ErrorString;
                            break;
                        }
                       // if (num > 500) break;
                    }


                }
            }
        }
    }
}
