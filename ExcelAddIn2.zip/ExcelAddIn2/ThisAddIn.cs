﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Excel = Microsoft.Office.Interop.Excel;
using Office = Microsoft.Office.Core;
using Microsoft.Office.Tools.Excel;
using System.IO;

namespace ExcelAddIn2
{
  public partial class ThisAddIn
  {
    void DisplayInExcel()
    {
      var excelApp = this.Application;
      string kronland;
      string staat;
      string buchtyp;
      string ort;
      string ortdetail;
      string konfession;
      string buch;
      string year;
      string temp;
      int idx;
      string isdp;
      int num;
      // Add a new Excel workbook.
      excelApp.Workbooks.Add();
      excelApp.Visible = true;
      excelApp.Range["A1"].Value = "KRONLAND";
      excelApp.Range["B1"].Value = "Heutiger_Staat";
      excelApp.Range["C1"].Value = "BuchTyp";
      excelApp.Range["D1"].Value = "Ort_Matrikenführung";
      excelApp.Range["E1"].Value = "Ort_Detail";
      excelApp.Range["F1"].Value = "KONFESSION";
      excelApp.Range["G1"].Value = "Buch";
      excelApp.Range["H1"].Value = "xSeite";
      excelApp.Range["I1"].Value = "Geburtsdatum_Jahr";
      excelApp.Range["J1"].Value = "Geburtsdatum_Monat";
      excelApp.Range["K1"].Value = "Geburtsdatum_Tag";
      excelApp.Range["L1"].Value = "Geburt_Ort";
      excelApp.Range["M1"].Value = "Geboren_V";
      excelApp.Range["N1"].Value = "Geboren_S";
      excelApp.Range["O1"].Value = "Vater_V";
      excelApp.Range["P1"].Value = "Vater_F";
      excelApp.Range["Q1"].Value = "Vater_B";
      excelApp.Range["R1"].Value = "Mutter_V";
      excelApp.Range["S1"].Value = "Mutter_F";
      excelApp.Range["T1"].Value = "Comment";
      excelApp.Range["AF1"].Value = "Zeuge 1_V";
      excelApp.Range["AG1"].Value = "Zeuge 1_F";
      excelApp.Range["AH1"].Value = "Zeuge 1_W";
      excelApp.Range["AI1"].Value = "Zeuge 1_B";
      excelApp.Range["AJ1"].Value = "Zeuge 2_V";
      excelApp.Range["AK1"].Value = "Zeuge 2_F";
      excelApp.Range["AL1"].Value = "Zeuge 2_W";
      excelApp.Range["AM1"].Value = "Zeuge 2_B";
      excelApp.Range["AN1"].Value = "Zeuge 3_V";
      excelApp.Range["AO1"].Value = "Zeuge 3_F";
      excelApp.Range["AP1"].Value = "Zeuge 3_W";
      excelApp.Range["AQ1"].Value = "Zeuge 3_B";
      excelApp.Range["AR1"].Value = "Zeuge 4_V";
      excelApp.Range["AS1"].Value = "Zeuge 4_F";
      excelApp.Range["AT1"].Value = "Zeuge 4_W";
      excelApp.Range["AU1"].Value = "Zeuge 4_B";
      num = 2;
      using (FileStream filestream = new FileStream("C:\\Users\\vissnh\\Downloads\\642.txt", FileMode.Open, FileAccess.Read))
      {
        using (StreamReader reader = new StreamReader(filestream, Encoding.Default))
        {
          kronland = reader.ReadLine();
          staat = reader.ReadLine();
          buchtyp = reader.ReadLine();
          ort = reader.ReadLine();
          ortdetail = reader.ReadLine();
          konfession = reader.ReadLine();
          buch = reader.ReadLine();
          year = "";
          isdp = "";
          while (!reader.EndOfStream)
          {
            var line = reader.ReadLine();
            if (line.Length == 0)
            {
              continue;
            }
            if ((line.Length.Equals(4)) && (line.Contains("DP") == false))
            {
              year = line;
              continue;
            }
            if (line.StartsWith("DP"))
            {
              line = line.Substring(3);
              isdp = line;
              continue;
            }
            if (!line.Contains(","))
            {
              continue;
            }
            idx = line.IndexOf(",");
            temp = line.Substring(0, idx);
            if (temp.Contains(".") == true)
            {
              line = "#," + line;
            }
            excelApp.Range["A" + num].Value = kronland;
            excelApp.Range["B" + num].Value = staat;
            excelApp.Range["C" + num].Value = buchtyp;
            excelApp.Range["D" + num].Value = ort;
            excelApp.Range["E" + num].Value = ortdetail;
            excelApp.Range["F" + num].Value = konfession;
            excelApp.Range["G" + num].Value = buch;
            excelApp.Range["I" + num].Value = year;
            excelApp.Range["H" + num].Value = isdp;
            if (line.Contains("####"))
            {

            }
            else
            {
              excelApp.Range["L" + num].Value = GetOrt(line);
              excelApp.Range["J" + num].Value = GetMonat(line);
              excelApp.Range["K" + num].Value = GetTag(line);
              excelApp.Range["M" + num].Value = GetVorname(line);
              excelApp.Range["O" + num].Value = GetVaterVorname(line);
              excelApp.Range["P" + num].Value = GetVaterNachname(line);
              excelApp.Range["Q" + num].Value = GetBeruf(line);
              excelApp.Range["R" + num].Value = GetMutterVorname(line);
              excelApp.Range["S" + num].Value = "";
              excelApp.Range["T" + num].Value = GetComment(line);
              excelApp.Range["AF" + num].Value = GetZeuge1V(line);
              excelApp.Range["AG" + num].Value = GetZeuge1F(line);
              excelApp.Range["AH" + num].Value = GetZeuge1W(line);
              excelApp.Range["AI" + num].Value = GetZeuge1B(line);
              excelApp.Range["AJ" + num].Value = GetZeuge2V(line);
              excelApp.Range["AK" + num].Value = GetZeuge2F(line);
              excelApp.Range["AL" + num].Value = GetZeuge2W(line);
              excelApp.Range["AM" + num].Value = GetZeuge2B(line);
              excelApp.Range["AN" + num].Value = GetZeuge3V(line);
              excelApp.Range["AO" + num].Value = GetZeuge3F(line);
              excelApp.Range["AP" + num].Value = GetZeuge3W(line);
              excelApp.Range["AQ" + num].Value = GetZeuge3B(line);
              excelApp.Range["AR" + num].Value = GetZeuge4V(line);
              excelApp.Range["AS" + num].Value = GetZeuge4F(line);
              excelApp.Range["AT" + num].Value = GetZeuge4W(line);
              excelApp.Range["AU" + num].Value = GetZeuge4B(line);
                        }
            num++;
            // if (num > 500) break;
          }


        }
      }
    }

    void DisplayInExcelMarry()
    {
      var excelApp = this.Application;
      string kronland;
      string staat;
      string buchtyp;
      string ort;
      string ortdetail;
      string konfession;
      string buch;
      string year;
      string isdp;
      int num;
      // Add a new Excel workbook.
      excelApp.Workbooks.Add();
      excelApp.Visible = true;
      excelApp.Range["A1"].Value = "KRONLAND";
      excelApp.Range["B1"].Value = "Heutiger_Staat";
      excelApp.Range["C1"].Value = "BuchTyp";
      excelApp.Range["D1"].Value = "Ort_Matrikenführung";
      excelApp.Range["E1"].Value = "Ort_Detail";
      excelApp.Range["F1"].Value = "KONFESSION";
      excelApp.Range["G1"].Value = "BUCH";
      excelApp.Range["H1"].Value = "xseite";
      excelApp.Range["I1"].Value = "Heiratsdatum_Jahr";
      excelApp.Range["J1"].Value = "Heiratsdatum_Monat";
      excelApp.Range["K1"].Value = "Heiratsdatum_Tag";
      excelApp.Range["L1"].Value = "Bräutigam_W";
      excelApp.Range["M1"].Value = "Bräutigam_V";
      excelApp.Range["N1"].Value = "Bräutigam_F";
      excelApp.Range["O1"].Value = "Bräutigam_S";
      excelApp.Range["P1"].Value = "Bräutigamvater_V";
      excelApp.Range["Q1"].Value = "Bräutigamvater_F";
      excelApp.Range["R1"].Value = "Braut_V";
      excelApp.Range["S1"].Value = "Braut_VEV";
      excelApp.Range["T1"].Value = "Braut_VEN";
      excelApp.Range["U1"].Value = "Braut_S";
      excelApp.Range["V1"].Value = "Brautvater_V";
      excelApp.Range["W1"].Value = "Brautvater_F";
      excelApp.Range["X1"].Value = "Sonstiges";
      excelApp.Range["Y1"].Value = "URL";
      excelApp.Range["Z1"].Value = "Einsender";
      excelApp.Range["AA1"].Value = "Abgabedatum";
      excelApp.Range["AB1"].Value = "Erfassungsmethode";
      excelApp.Range["AC1"].Value = "Erfassungsinhalt";
      excelApp.Range["AD1"].Value = "Auskunft";
      excelApp.Range["AE1"].Value = "Braut_W";
      excelApp.Range["AF1"].Value = "Zeuge 1_V";
      excelApp.Range["AG1"].Value = "Zeuge 1_F";
      excelApp.Range["AH1"].Value = "Zeuge 1_W";
      excelApp.Range["AI1"].Value = "Zeuge 1_B";
      excelApp.Range["AJ1"].Value = "Zeuge 2_V";
      excelApp.Range["AK1"].Value = "Zeuge 2_F";
      excelApp.Range["AL1"].Value = "Zeuge 2_W";
      excelApp.Range["AM1"].Value = "Zeuge 2_B";
      excelApp.Range["AN1"].Value = "Zeuge 3_V";
      excelApp.Range["AO1"].Value = "Zeuge 3_F";
      excelApp.Range["AP1"].Value = "Zeuge 3_W";
      excelApp.Range["AQ1"].Value = "Zeuge 3_B";
      excelApp.Range["AR1"].Value = "Zeuge 4_V";
      excelApp.Range["AS1"].Value = "Zeuge 4_F";
      excelApp.Range["AT1"].Value = "Zeuge 4_W";
      excelApp.Range["AU1"].Value = "Zeuge 4_B";
      excelApp.Range["AV1"].Value = "BRÄUTIGAM_B";
      excelApp.Range["AW1"].Value = "BRAUTVATER_B";
      excelApp.Range["AX1"].Value = "BRÄUTIGAMVATER_B";

            num = 2;
      using (FileStream filestream = new FileStream("C:\\Users\\vissnh\\Downloads\\647.txt", FileMode.Open, FileAccess.Read))
      {
        using (StreamReader reader = new StreamReader(filestream, Encoding.Default))
        {
          reader.ReadLine();
          kronland = reader.ReadLine();
          staat = reader.ReadLine();
          buchtyp = reader.ReadLine();
          ort = reader.ReadLine();
          ortdetail = reader.ReadLine();
          konfession = reader.ReadLine();
          buch = reader.ReadLine();
          year = "";
          isdp = "";
          while (!reader.EndOfStream)
          {
            var line = reader.ReadLine();
            if (line.Length == 0)
            {
              continue;
            }
            if (line.Equals(" "))
            {
              continue;
            }
            if ((line.Length.Equals(4)) && (line.Contains("DP") == false))
            {
              year = line;
              continue;
            }
            if (line.StartsWith("DP"))
            {
              line = line.Substring(3);
              isdp = line;
              continue;
            }
            excelApp.Range["A" + num].Value = kronland;
            excelApp.Range["B" + num].Value = staat;
            excelApp.Range["C" + num].Value = buchtyp;
            excelApp.Range["D" + num].Value = ort;
            excelApp.Range["E" + num].Value = ortdetail;
            excelApp.Range["F" + num].Value = konfession;
            excelApp.Range["G" + num].Value = buch;
            excelApp.Range["H" + num].Value = isdp;
            excelApp.Range["I" + num].Value = year;
            excelApp.Range["J" + num].Value = GetMonat(line);
            excelApp.Range["K" + num].Value = GetTag(line);
            excelApp.Range["M" + num].Value = GetVorname(line);
            excelApp.Range["P" + num].Value = GetVaterVorname(line);
            excelApp.Range["N" + num].Value = GetVaterNachname(line);
            excelApp.Range["Q" + num].Value = GetVaterNachname(line);
            excelApp.Range["O" + num].Value = "";
            excelApp.Range["R" + num].Value = GetBrautVorname(line);
            if (IsWidow(line))
            {
              excelApp.Range["S" + num].Value = GetBrautVaterVorname(line);
              excelApp.Range["T" + num].Value = GetBrautVaterNachname(line);
              excelApp.Range["U" + num].Value = "Widow";
            }
            else
            {
              excelApp.Range["V" + num].Value = GetBrautVaterVorname(line);
              excelApp.Range["W" + num].Value = GetBrautVaterNachname(line);
            }
            if (IsWidower(line))
            {
              excelApp.Range["O" + num].Value = "Widower";
            }
            excelApp.Range["L" + num].Value = GetHochzeitsOrt(line);
            excelApp.Range["AE" + num].Value = GetBrautOrt(line);
            excelApp.Range["X" + num].Value = GetMarryComment(line);
            excelApp.Range["AF" + num].Value = GetZeuge1V(line);
            excelApp.Range["AG" + num].Value = GetZeuge1F(line);
            excelApp.Range["AH" + num].Value = GetZeuge1W(line);
            excelApp.Range["AI" + num].Value = GetZeuge1B(line);
            excelApp.Range["AJ" + num].Value = GetZeuge2V(line);
            excelApp.Range["AK" + num].Value = GetZeuge2F(line);
            excelApp.Range["AL" + num].Value = GetZeuge2W(line);
            excelApp.Range["AM" + num].Value = GetZeuge2B(line);
            excelApp.Range["AN" + num].Value = GetZeuge3V(line);
            excelApp.Range["AO" + num].Value = GetZeuge3F(line);
            excelApp.Range["AP" + num].Value = GetZeuge3W(line);
            excelApp.Range["AQ" + num].Value = GetZeuge3B(line);
            excelApp.Range["AR" + num].Value = GetZeuge4V(line);
            excelApp.Range["AS" + num].Value = GetZeuge4F(line);
            excelApp.Range["AT" + num].Value = GetZeuge4W(line);
            excelApp.Range["AU" + num].Value = GetZeuge4B(line);
            excelApp.Range["AB" + num].Value = "2";
            excelApp.Range["Z" + num].Value = "Steffen Häuser";
            excelApp.Range["AA" + num].Value = DateTime.Today.ToString();
            excelApp.Range["AD" + num].Value = "N";
            excelApp.Range["AC" + num].Value = "TEIL";
            excelApp.Range["AV" + num].Value = GetGroomBeruf(line);
            excelApp.Range["AW" + num].Value = GetGroomFatherBeruf(line);
            excelApp.Range["AX" + num].Value = GetBrideFatherBeruf(line);
                        
            num++;
            // if (num > 500) break;
          }


        }
      }
    }

    private object GetBrautOrt(string line)
    {
      string bck = line;
      int idx;
      if (bck.Contains("Ort des Bräutigams nicht angegeben"))
      {
        idx = line.IndexOf(",");
        line = line.Substring(0, idx);
        if (line.Contains(" und ") == false) return line;
        idx = line.IndexOf(" und ");
        line = line.Substring(0, idx);

        return line;
      }
      idx = line.IndexOf(",");
      line = line.Substring(0, idx);
      if (line.Contains(" und ") == false) return "";
      idx = line.IndexOf(" und ");
      line = line.Substring(idx + 4);
      return line;
    }

    private dynamic GetHochzeitsOrt(string line)
    {
      string bck = line;
      if (bck.Contains("Ort des Bräutigams nicht angegeben"))
      {
        return "";
      }
      int idx = line.IndexOf(",");
      line = line.Substring(0, idx);
      if (line.Contains(" und ") == false) return line;
      idx = line.IndexOf(" und ");
      line = line.Substring(0, idx);
      return line;
    }

    string GetOrt(string line)
    {
      try
      {
        string line2 = "";
        int idx = line.IndexOf("(Beruf");
        if (idx != -1)
        {
          line2 = line.Substring(idx + 6);
          idx = line2.IndexOf(")");
          line2 = line2.Substring(0, idx);
          idx = line2.IndexOf(",");
          if (idx == -1)
          {
            line2 = "";
          }
          else
          {
            idx = line2.IndexOf("#");
            if (idx == -1) line2 = "";
            else line2 = line2.Substring(idx);
          }
        }
        idx = line.IndexOf("(#");
        if (idx != -1)
        {
          if (!line.Contains("(#)"))
          {
            line2 = line.Substring(idx + 1);
            idx = line2.IndexOf(")");
            line2 = line2.Substring(0, idx);
          }
        }
        idx = line.IndexOf(",");
        if (line2.Contains("#"))
        {
          line2 = " " + line2;
        }
        string tmp = line.Substring(0, idx) + line2;
        return tmp;
      }
      catch (Exception)
      {

        int i = 0;
        i++;
        return "";
      }
    }

    string GetOrtSterbe(string line)
    {
      int idx = line.IndexOf(",");
      string tmp = line.Substring(0, idx);

      idx = line.IndexOf("(");
      if (idx != -1)
      {
        string bck;
        int idx2 = 0;
        line = line.Substring(idx + 1);
        if (line.Contains("vidua,"))
        {
          line = line.Substring(7);
          if (line.IndexOf("#") == -1)
          {
            return tmp;
          }
          idx = line.IndexOf("#") + 1;
          line = line.Substring(idx);
          idx = line.IndexOf(",");
          if (idx == -1)
          {
            idx = line.IndexOf(")");
            line = line.Substring(0, idx);
          }
          idx = line.IndexOf(",");
          if (idx != -1)
          {
            line = line.Substring(0, idx);
          }
          else
          {
            idx = line.IndexOf(")");
            if (idx != -1)
            {
              line = line.Substring(0, idx);
            }
          }
          idx = line.IndexOf(")");
          if (idx != -1)
          {
            line = line.Substring(0, idx);
          }
          tmp = tmp + " No. " + line;
        }
        else if (line.Contains("Tochter,"))
        {
          line = line.Substring(8);
          if (line.IndexOf("#") == -1)
          {
            return tmp;
          }
          idx = line.IndexOf("#") + 1;
          line = line.Substring(idx);
          idx = line.IndexOf(",");
          if (idx == -1)
          {
            idx = line.IndexOf(")");
            line = line.Substring(0, idx);
          }
          else
          {
            line = line.Substring(0, idx);
          }
          if (idx != -1)
          {
            line = line.Substring(0, idx);
          }
          else
          {
            idx = line.IndexOf(")");
            if (idx != -1)
            {
              line = line.Substring(0, idx);
            }
          }
          idx = line.IndexOf(")");
          if (idx != -1)
          {
            line = line.Substring(0, idx);
          }
          tmp = tmp + " No. " + line;
        }
        else if (line.Contains("Ehefrau,"))
        {
          line = line.Substring(8);
          if (line.IndexOf("#") == -1)
          {
            return tmp;
          }
          idx = line.IndexOf("#") + 1;
          line = line.Substring(idx);
          idx = line.IndexOf(",");
          if (idx == -1)
          {
            idx = line.IndexOf(")");
            line = line.Substring(0, idx);
          }
          else
          {
            line = line.Substring(0, idx);
          }
          if (idx != -1)
          {
            line = line.Substring(0, idx);
          }
          else
          {
            idx = line.IndexOf(")");
            if (idx != -1)
            {
              line = line.Substring(0, idx);
            }
          }
          idx = line.IndexOf(")");
          if (idx != -1)
          {
            line = line.Substring(0, idx);
          }
          tmp = tmp + " No. " + line;
        }
        else if (line.Contains("Witwe,"))
        {
          line = line.Substring(6);
          if (line.IndexOf("#") == -1)
          {
            return tmp;
          }
          idx = line.IndexOf("#") + 1;
          line = line.Substring(idx);
          idx = line.IndexOf(",");
          if (idx == -1)
          {
            idx = line.IndexOf(")");
            line = line.Substring(0, idx);
          }
          else
          {
            line = line.Substring(0, idx);
          }
          if (idx != -1)
          {
            line = line.Substring(0, idx);
          }
          else
          {
            if (line.StartsWith("#") == false)
            {
              return tmp;
            }
            idx = line.IndexOf(")");
            if (idx != -1)
            {
              line = line.Substring(0, idx);
            }
          }
          idx = line.IndexOf(")");
          if (idx != -1)
          {
            line = line.Substring(0, idx);
          }
          tmp = tmp + " No. " + line;
        }
        else
        {
          if (line.IndexOf("#") == -1)
          {
            return tmp;
          }
          idx = line.IndexOf("#") + 1;
          line = line.Substring(idx);
          idx = line.IndexOf(",");
          if (idx == -1)
          {
            idx = line.IndexOf(")");
            line = line.Substring(0, idx);
          }
          else
          {
            line = line.Substring(0, idx);
          }
          if (idx != -1)
          {
            line = line.Substring(0, idx);
          }
          else
          {
            idx = line.IndexOf(")");
            if (idx != -1)
            {
              line = line.Substring(0, idx);
            }
          }
          idx = line.IndexOf(")");
          if (idx != -1)
          {
            line = line.Substring(0, idx);
          }
          tmp = tmp + " No. " + line;

        }
      }

      if (tmp.StartsWith("- "))
      {
        tmp = tmp.Replace("- ", "");
      }

      if (tmp.EndsWith(" No. "))
      {
        tmp = tmp.Replace(" No. ", "");
      }

      return tmp;
    }

    private object GetVaterVorname(string line)
    {
      try
      {
        int idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(0, idx);
        return line;
      }
      catch (Exception ex)
      {
        int i = 0;
        i++;
        return null;
      }
    }

    private object GetVaterNachname(string line)
    {
      try
      {
        int idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(0, idx);
      }
      catch (Exception ex)
      {
        int i = 0;
        i++;
      }
      return line;
    }

    private object GetBrautVorname(string line)
    {
      int idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(0, idx);
      return line;
    }

    private object GetBrautVaterVorname(string line)
    {
      int idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(0, idx);
      return line;
    }

    private object GetBrautVaterNachname(string line)
    {
      int idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      if (idx == -1)
      {
        idx = line.IndexOf(" (");
        if (idx == -1) return line;
        line = line.Substring(0, idx);
        return line;
      }
      line = line.Substring(0, idx);
      idx = line.IndexOf(" (");
      if (idx == -1) return line;
      line = line.Substring(0, idx);
      return line;
    }

    private bool IsWidower(string line)
    {
      int idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      if (idx == -1) return false;
      line = line.Substring(idx + 1);
      if (line.StartsWith("W,")) return true;
      if (line.StartsWith("W ")) return true;
      return false;
    }

    private bool IsWidow(string line)
    {
      int idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      if (idx == -1) return false;
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      if (idx == -1) return false;
      line = line.Substring(idx + 1);
      if (line.StartsWith("W ")) return true;
      return false;
    }

    private int GetAgeYearsInt(string line)
    {
      string age;

      try
      {
        age = (string)GetAgeYears(line);
        return Int32.Parse(age);
      }
      catch (Exception)
      {

        return 0;
      }
    }

    private object GetAgeYears(string line)
    {
      int idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(" ");
      if (idx != -1)
      {
        line = line.Substring(0, idx);
      }
      if (line.Contains("y"))
      {
        idx = line.IndexOf("y");
        line = line.Substring(0, idx);
        return line;
      }
      if (line.Contains("d"))
      {
        return "";
      }
      if (line.Contains("m"))
      {
        return "";
      }
      if (line.Contains("w"))
      {
        return "";
      }
      return line;
    }

    private object GetAgeMonths(string line)
    {
      try
      {
        bool isNr = false;
        int idx = line.IndexOf(",");
        int num = 0;
        string bck = "";
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(" ");
        if (idx != -1)
        {
          line = line.Substring(0, idx);
        }
        if (line.Contains("w"))
        {
          if (line.Contains("y"))
          {
            idx = line.IndexOf("y");
            line = line.Substring(idx + 1);
          }
          idx = line.IndexOf("w");
          if (idx != -1)
          {
            bck = line.Substring(0, idx);
          }
          if (bck.Contains("#") == false)
          {
            num = Int32.Parse(bck);
            num = num * 7;
            num = num / 30;
          }
          else
          {
            bck = bck.Replace("#", "");
            isNr = true;
            num = Int32.Parse(bck);
            num = num * 7;
            num = num / 30;
          }
        }
        if (line.Contains("m"))
        {
          if (line.Contains("y"))
          {
            idx = line.IndexOf("y");
            line = line.Substring(idx + 1);
          }
          idx = line.IndexOf("m");
          bck = line.Substring(0, idx);
          if (bck.Contains("#") == false)
          {
            num = num + Int32.Parse(bck);
          }
          else
          {
            bck = bck.Replace("#", "");
            num = num + Int32.Parse(bck);
            isNr = true;
          }
        }
        if (num == 0) return "";

        if (isNr)
        {
          return num + "#";
        }
        return num.ToString();
      }
      catch (Exception ex)
      {
        int i = 0;
        i++;
      }
      return 0;
    }

    private object GetAgeDays(string line)
    {
      try
      {
        bool isNr = false;
        int idx = line.IndexOf(",");
        int num = 0;
        string bck = "";
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(" ");
        if (idx != -1)
        {
          line = line.Substring(0, idx);
        }
        if (line.Contains("w"))
        {
          if (line.Contains("y"))
          {
            idx = line.IndexOf("y");
            line = line.Substring(idx + 1);
          }
          if (line.Contains("m"))
          {
            idx = line.IndexOf("m");
            line = line.Substring(idx + 1);
          }
          idx = line.IndexOf("w");
          if (idx != -1)
          {
            bck = line.Substring(0, idx);
          }
          if (bck.Contains("#") == false)
          {
            int num2 = 0;
            num = Int32.Parse(bck);
            num2 = num;
            num = num * 7;
            num = num / 30;
            num = (num2 - ((num * 30) / 7)) * 7;
          }
          else
          {
            int num2 = 0;
            bck = bck.Replace("#", "");
            num = Int32.Parse(bck);
            num2 = num;
            num = num * 7;
            num = num / 30;
            num = (num2 - ((num * 30) / 7)) * 7;
            isNr = true;
          }
        }
        if (line.Contains("d"))
        {
          if (line.Contains("y"))
          {
            idx = line.IndexOf("y");
            line = line.Substring(idx + 1);
          }
          if (line.Contains("m"))
          {
            idx = line.IndexOf("m");
            line = line.Substring(idx + 1);
          }
          if (line.Contains("w"))
          {
            idx = line.IndexOf("w");
            line = line.Substring(idx + 1);
          }
          idx = line.IndexOf("d");
          bck = line.Substring(0, idx);
          if (bck.Contains("#") == false)
          {
            num = num + Int32.Parse(bck);
          }
          else
          {
            bck = bck.Replace("#", "");
            num = num + Int32.Parse(bck);
            isNr = true;
          }
        }
        if (num == 0) return "";

        if (isNr)
        {
          return num + "#";
        }

        return num.ToString();
      }
      catch
      {
        int i = 0;
        i++;
      }
      return 0;
    }

    private object GetDeathComment(string line)
    {
      int idx = line.IndexOf(")");
      string bck;
      bck = line.Substring(idx + 1);
      if (bck.Contains("("))
      {
        bck = line.Substring(line.IndexOf("(") + 1);
        idx = bck.IndexOf(")");
        bck = bck.Substring(idx);
        idx = bck.IndexOf("(");
        bck = bck.Substring(idx + 1);
        bck = bck.Replace(")", "");
        idx = bck.IndexOf("U:");
        if (idx != -1)
        {
          bck = bck.Substring(0, idx);
        }

        if (bck.StartsWith("geboren"))
        {
          if (bck.Contains(","))
          {
            idx = bck.IndexOf(",");
            bck = bck.Substring(idx + 1);
          }
          else
          {
            bck = "";
          }
        }
        return bck;
      }

      return "";
    }

    private object GetMutterVorname(string line)
    {
      int idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf("U:");
      if (idx != -1)
      {
        line = line.Substring(0, idx);
        if (line.EndsWith(" ")) line = line.Substring(0, idx - 1);
      }
      idx = line.IndexOf("(");
      if (idx == -1) return line;
      line = line.Substring(0, idx);
      if (line.EndsWith(" ")) line = line.Substring(0, idx - 1);
      idx = line.IndexOf("U:");
      if (idx != -1)
      {
        line = line.Substring(0, idx);
        if (line.EndsWith(" ")) line = line.Substring(0, idx - 1);
      }
      return line;
    }

    private object GetMotherVorname(string line)
    {
      int idx = line.IndexOf("U:");
      if (idx == -1) return "";
      line = line.Substring(idx + 2);
      if (line.Contains("unehelich"))
      {
        idx = line.IndexOf("unehelich");
        line = line.Substring(idx + 9);
        idx = line.IndexOf("von ");
        line = line.Substring(idx + 4);
        idx = line.IndexOf(" aus");
        if (idx == -1)
        {
          idx = line.IndexOf(" ");
          line = line.Substring(0, idx);
          return line;
        }
        else
        {
          line = line.Substring(0, idx);

          idx = line.IndexOf(" ");
          line = line.Substring(0, idx);
          return line;
        }
      }
      if (line.Contains("Kind von"))
      {
        idx = line.IndexOf("Kind ");
        line = line.Substring(idx + 5);
        idx = line.IndexOf("von ");
        line = line.Substring(idx + 4);
        idx = line.IndexOf(" aus");
        if (idx == -1)
        {
          idx = line.IndexOf(" ");
          line = line.Substring(0, idx);
          return line;
        }
        else
        {
          line = line.Substring(0, idx);

          idx = line.IndexOf(" ");
          line = line.Substring(0, idx);
          return line;
        }
      }
      if (line.Contains("Kind ist Tochter"))
      {
        idx = line.IndexOf("Kind ist Tochter");
        line = line.Substring(idx + 16);
        idx = line.IndexOf("der ");
        line = line.Substring(idx + 4);
        idx = line.IndexOf(" aus");
        if (idx == -1)
        {
          idx = line.IndexOf(" ");
          line = line.Substring(0, idx);
          return line;
        }
        else
        {
          line = line.Substring(0, idx);

          idx = line.IndexOf(" ");
          line = line.Substring(0, idx);
          return line;
        }
      }
      if (line.Contains("Kind ist Sohn"))
      {
        idx = line.IndexOf("Kind ist Sohn");
        line = line.Substring(idx + 13);
        idx = line.IndexOf("der ");
        line = line.Substring(idx + 4);
        idx = line.IndexOf(" aus");
        if (idx == -1)
        {
          idx = line.IndexOf(" ");
          line = line.Substring(0, idx);
          return line;
        }
        else
        {
          line = line.Substring(0, idx);

          idx = line.IndexOf(" ");
          line = line.Substring(0, idx);
          return line;
        }
      }
      return "";
    }

    private object GetMotherNachname(string line)
    {
      int idx = line.IndexOf("U:");
      if (idx == -1) return "";
      line = line.Substring(idx + 2);
      if (line.Contains("unehelich"))
      {
        idx = line.IndexOf("unehelich");
        line = line.Substring(idx + 9);
        idx = line.IndexOf("von ");
        line = line.Substring(idx + 4);
        idx = line.IndexOf(" aus");
        if (idx == -1)
        {
          idx = line.IndexOf(" ");
          line = line.Substring(idx + 1);
          return line;
        }
        else
        {
          line = line.Substring(0, idx);

          idx = line.IndexOf(" ");
          line = line.Substring(idx + 1);
          return line;
        }
      }
      if (line.Contains("Kind von"))
      {
        idx = line.IndexOf("Kind ");
        line = line.Substring(idx + 5);
        idx = line.IndexOf("von ");
        line = line.Substring(idx + 4);
        idx = line.IndexOf(" aus");
        if (idx == -1)
        {
          idx = line.IndexOf(" ");
          line = line.Substring(idx + 1);
          return line;
        }
        else
        {
          line = line.Substring(0, idx);

          idx = line.IndexOf(" ");
          line = line.Substring(idx + 1);
          return line;
        }
      }
      if (line.Contains("Kind ist Tochter"))
      {
        idx = line.IndexOf("Kind ist Tochter");
        line = line.Substring(idx + 16);
        idx = line.IndexOf("der ");
        line = line.Substring(idx + 4);
        idx = line.IndexOf(" aus");
        if (idx == -1)
        {
          idx = line.IndexOf(" ");
          line = line.Substring(idx + 1);
          return line;
        }
        else
        {
          line = line.Substring(0, idx);

          idx = line.IndexOf(" ");
          line = line.Substring(idx + 1);
          return line;
        }
      }
      if (line.Contains("Kind ist Sohn"))
      {
        idx = line.IndexOf("Kind ist Sohn");
        line = line.Substring(idx + 13);
        idx = line.IndexOf("der ");
        line = line.Substring(idx + 4);
        idx = line.IndexOf(" aus");
        if (idx == -1)
        {
          idx = line.IndexOf(" ");
          line = line.Substring(idx + 1);
          return line;
        }
        else
        {
          line = line.Substring(0, idx);

          idx = line.IndexOf(" ");
          line = line.Substring(idx + 1);
          return line;
        }
      }
      return "";
    }

    private object GetVorname(string line)
    {
      int idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(0, idx);
      return line;
    }

    private object GetTag(string line)
    {
      try
      {
        int idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(".");
        line = line.Substring(0, idx);
      }
      catch (Exception ex)
      {
        int i = 0;
        i++;
      }
      return line;
    }

    private object GetMonat(string line)
    {
      int idx = line.IndexOf(",");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(".");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(",");
      line = line.Substring(0, idx);
      return line;
    }

    private object GetDeathBeruf2(string line)
    {
      string bck = "";
      int idx = line.IndexOf("(");
      if (idx != -1)
      {
        line = line.Substring(idx + 1);
        idx = line.IndexOf(")");
        line = line.Substring(0, idx);
        idx = line.IndexOf(",");
        if (idx == -1)
        {
          if (line.Contains("#"))
          {
            return "";
          }
          if (line.StartsWith("Ehefrau")) line = "";
          if (line.StartsWith("vidua")) line = "";
          if (line.StartsWith("Witwe")) line = "";
          if (line.StartsWith("Tochter")) line = "";
          return line;
        }
        bck = line;
        if (bck.StartsWith("vidua,"))
        {
          line = bck.Substring(6);
          idx = line.IndexOf(",");
        }
        if (bck.StartsWith("Witwe,"))
        {
          line = bck.Substring(6);
          idx = line.IndexOf(",");
        }
        if (bck.StartsWith("Tochter,"))
        {
          line = bck.Substring(8);
          idx = line.IndexOf(",");
        }
        if (bck.StartsWith("Ehefrau,"))
        {
          line = bck.Substring(8);
          idx = line.IndexOf(",");
        }
        line = line.Substring(idx + 1);
        line = line.Replace(" #", "#");
        if ((line.StartsWith("#")) && (line != "#"))
        {
          if (idx == -1) return "";
          line = bck.Substring(0, idx);


          return line;
        }
        if (line == "#")
        {
          return line;
        }
        idx = line.IndexOf(",");
        if (idx == -1)
        {
          if (line.Contains("#"))
          {
            return "";
          }
          return line;
        }
        if (line.StartsWith("#"))
        {
          line = line.Substring(idx + 1);
          return line;
        }
        line = line.Substring(0, idx);
        return line;
      }
      return "";
    }

    private object GetDeathBeruf(string line)
    {
      string bck = (string)GetDeathBeruf2(line);
      bck = bck.Replace("Beruf ", "");
      return bck;
    }

    private object GetBeruf(string line)
    {
      int idx = line.IndexOf("Beruf ");
      if (idx == -1) return "";
      line = line.Substring(idx + 6);
      idx = line.IndexOf(")");
      line = line.Substring(0, idx);
      if (line.Contains(","))
      {
        idx = line.IndexOf(",");
        line = line.Substring(0, idx);
      }

      return line;
    }

    private object GetMarryComment(string line)
    {
      string comment;
      string temp;

      int idx = line.IndexOf("(");
      if (idx == -1) return "";
      line = line.Substring(idx + 1);
      idx = line.IndexOf(")");
      if (idx == -1) return "";
      comment = line.Substring(0, idx);
      idx = comment.IndexOf("Berufe ");
      if (idx == -1) return comment;
      temp = line.Substring(idx + 1);
      idx = temp.IndexOf("/");
      if (idx == -1) return comment;
      temp = temp.Substring(idx + 1);
      idx = temp.IndexOf(",");
      if (idx == -1) return comment;
      temp = temp.Substring(idx + 1);
      if (temp.StartsWith(" ")) temp = temp.Substring(1);
      return temp;
    }

    private object GetGroomBeruf(string line)
    {
            string beruf;
            int idx = line.IndexOf("(");
            if (idx == -1) return "";
            line = line.Substring(idx + 1);
            idx = line.IndexOf(")");
            if (idx == -1) return "";

            beruf = line.Substring(0, idx);
            idx = line.IndexOf("Berufe ");
            if (idx == -1) return "";
            beruf = beruf.Substring(idx + 1);
            idx = beruf.IndexOf("/");
            if (idx == -1) return "";
            beruf = beruf.Substring(0, idx);
            idx = beruf.IndexOf("Der Vater des Bräutigams war ");
            if (idx == -1) return beruf;
            beruf = beruf.Substring(idx + 1);
            idx = beruf.IndexOf(",");
            if (idx == -1) return "";
            beruf = beruf.Substring(idx + 1);
            if (beruf.StartsWith(" ")) beruf = beruf.Substring(1);
            return beruf;
    }

    private object GetGroomFatherBeruf(string line)
    {
            string beruf;
            int idx = line.IndexOf("Der Vater des Bräutigams war ");
            if (idx == -1) return "";
            beruf = line.Substring(idx + 1);
            idx = beruf.IndexOf(")");
            if (idx == -1) return "";
            beruf = beruf.Substring(0, idx);

            return beruf;
    }

    private object GetBrideFatherBeruf(string line)
    {
            string beruf;
            int idx = line.IndexOf("(");
            if (idx == -1) return "";
            line = line.Substring(idx + 1);
            idx = line.IndexOf(")");
            if (idx == -1) return "";

            beruf = line.Substring(0, idx);
            idx = line.IndexOf("Berufe ");
            if (idx == -1) return "";
            beruf = beruf.Substring(idx + 1);
            idx = beruf.IndexOf("/");
            if (idx == -1) return "";
            beruf = beruf.Substring(idx+1);
            idx = beruf.IndexOf(",");
            if (idx != -1) beruf = beruf.Substring(0, idx);

            return beruf;
    }

        private object GetZeuge1V(string line)
    {
      string zeuge;

      int idx = line.IndexOf("[");
      if (idx == -1) return "";
      line = line.Substring(idx + 1);
      idx = line.IndexOf("]");
      if (idx == -1) return "";
      zeuge=line.Substring(0, idx);
      idx = zeuge.IndexOf("1:<");
      if (idx == -1) return "";
      zeuge = zeuge.Substring(idx + 1);
      idx = zeuge.IndexOf("1>");
      if (idx == -1) return "";
      else zeuge = zeuge.Substring(0, idx);
      idx = zeuge.IndexOf(",");
      if (idx == -1) return "";
      return zeuge.Substring(0, idx);
    }

    private object GetZeuge1F(string line)
    {
            string zeuge;

            int idx = line.IndexOf("[");
            if (idx == -1) return "";
            line = line.Substring(idx + 1);
            idx = line.IndexOf("]");
            if (idx == -1) return "";
            zeuge = line.Substring(0, idx);
            idx = zeuge.IndexOf("1:<");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf("1>");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(0, idx);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf(",");
            if (idx != -1)
            {
                zeuge = zeuge.Substring(0, idx);
            }
            return zeuge;
    }

    private object GetZeuge1W(string line)
    {
            string zeuge;

            int idx = line.IndexOf("[");
            if (idx == -1) return "";
            line = line.Substring(idx + 1);
            idx = line.IndexOf("]");
            if (idx == -1) return "";
            zeuge = line.Substring(0, idx);
            idx = zeuge.IndexOf("1:<");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf("1>");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(0, idx);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            else
            {
                zeuge = zeuge.Substring(idx+1);
            }
            idx = zeuge.IndexOf(",");
            if (idx !=-1)
            {
                zeuge = zeuge.Substring(0, idx);
            }
            return zeuge;
    }

    private object GetZeuge1B(string line)
    {
            string zeuge;

            int idx = line.IndexOf("[");
            if (idx == -1) return "";
            line = line.Substring(idx + 1);
            idx = line.IndexOf("]");
            if (idx == -1) return "";
            zeuge = line.Substring(0, idx);
            idx = zeuge.IndexOf("1:<");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf("1>");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(0, idx);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            else
            {
                zeuge = zeuge.Substring(idx + 1);
            }
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            else
            {
                zeuge = zeuge.Substring(idx+1);
            }
            return zeuge;
    }

    private object GetZeuge2V(string line)
    {
            string zeuge;

            int idx = line.IndexOf("[");
            if (idx == -1) return "";
            line = line.Substring(idx + 1);
            idx = line.IndexOf("]");
            if (idx == -1) return "";
            zeuge = line.Substring(0, idx);
            idx = zeuge.IndexOf("2:<");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf("2>");
            if (idx == -1) return "";
            else zeuge = zeuge.Substring(0, idx);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            return zeuge.Substring(0, idx);
    }

    private object GetZeuge2F(string line)
    {
            string zeuge;

            int idx = line.IndexOf("[");
            if (idx == -1) return "";
            line = line.Substring(idx + 1);
            idx = line.IndexOf("]");
            if (idx == -1) return "";
            zeuge = line.Substring(0, idx);
            idx = zeuge.IndexOf("2:<");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf("2>");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(0, idx);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf(",");
            if (idx != -1)
            {
                zeuge = zeuge.Substring(0, idx);
            }
            return zeuge;
    }

    private object GetZeuge2W(string line)
    {
            string zeuge;

            int idx = line.IndexOf("[");
            if (idx == -1) return "";
            line = line.Substring(idx + 1);
            idx = line.IndexOf("]");
            if (idx == -1) return "";
            zeuge = line.Substring(0, idx);
            idx = zeuge.IndexOf("2:<");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf("2>");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(0, idx);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            else
            {
                zeuge = zeuge.Substring(idx + 1);
            }
            idx = zeuge.IndexOf(",");
            if (idx != -1)
            {
                zeuge = zeuge.Substring(0, idx);
            }
            return zeuge;
    }

    private object GetZeuge2B(string line)
    {
            string zeuge;

            int idx = line.IndexOf("[");
            if (idx == -1) return "";
            line = line.Substring(idx + 1);
            idx = line.IndexOf("]");
            if (idx == -1) return "";
            zeuge = line.Substring(0, idx);
            idx = zeuge.IndexOf("2:<");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf("2>");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(0, idx);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            else
            {
                zeuge = zeuge.Substring(idx + 1);
            }
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            else
            {
                zeuge = zeuge.Substring(idx + 1);
            }
            return zeuge;
    }

    private object GetZeuge3V(string line)
    {
            string zeuge;

            int idx = line.IndexOf("[");
            if (idx == -1) return "";
            line = line.Substring(idx + 1);
            idx = line.IndexOf("]");
            if (idx == -1) return "";
            zeuge = line.Substring(0, idx);
            idx = zeuge.IndexOf("3:<");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf("3>");
            if (idx == -1) return "";
            else zeuge = zeuge.Substring(0, idx);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            return zeuge.Substring(0, idx);
    }

    private object GetZeuge3F(string line)
    {
            string zeuge;

            int idx = line.IndexOf("[");
            if (idx == -1) return "";
            line = line.Substring(idx + 1);
            idx = line.IndexOf("]");
            if (idx == -1) return "";
            zeuge = line.Substring(0, idx);
            idx = zeuge.IndexOf("3:<");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf("3>");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(0, idx);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf(",");
            if (idx != -1)
            {
                zeuge = zeuge.Substring(0, idx);
            }
            return zeuge;
    }

    private object GetZeuge3W(string line)
    {
            string zeuge;

            int idx = line.IndexOf("[");
            if (idx == -1) return "";
            line = line.Substring(idx + 1);
            idx = line.IndexOf("]");
            if (idx == -1) return "";
            zeuge = line.Substring(0, idx);
            idx = zeuge.IndexOf("3:<");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf("3>");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(0, idx);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            else
            {
                zeuge = zeuge.Substring(idx + 1);
            }
            idx = zeuge.IndexOf(",");
            if (idx != -1)
            {
                zeuge = zeuge.Substring(0, idx);
            }
            return zeuge;
    }

    private object GetZeuge3B(string line)
    {
            string zeuge;

            int idx = line.IndexOf("[");
            if (idx == -1) return "";
            line = line.Substring(idx + 1);
            idx = line.IndexOf("]");
            if (idx == -1) return "";
            zeuge = line.Substring(0, idx);
            idx = zeuge.IndexOf("3:<");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf("3>");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(0, idx);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            else
            {
                zeuge = zeuge.Substring(idx + 1);
            }
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            else
            {
                zeuge = zeuge.Substring(idx + 1);
            }
            return zeuge;
    }

    private object GetZeuge4V(string line)
    {
            string zeuge;

            int idx = line.IndexOf("[");
            if (idx == -1) return "";
            line = line.Substring(idx + 1);
            idx = line.IndexOf("]");
            if (idx == -1) return "";
            zeuge = line.Substring(0, idx);
            idx = zeuge.IndexOf("4:<");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf("4>");
            if (idx == -1) return "";
            else zeuge = zeuge.Substring(0, idx);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            return zeuge.Substring(0, idx);
    }

    private object GetZeuge4F(string line)
    {
            string zeuge;

            int idx = line.IndexOf("[");
            if (idx == -1) return "";
            line = line.Substring(idx + 1);
            idx = line.IndexOf("]");
            if (idx == -1) return "";
            zeuge = line.Substring(0, idx);
            idx = zeuge.IndexOf("4:<");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf("4>");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(0, idx);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf(",");
            if (idx != -1)
            {
                zeuge = zeuge.Substring(0, idx);
            }
            return zeuge;
    }

    private object GetZeuge4W(string line)
    {
            string zeuge;

            int idx = line.IndexOf("[");
            if (idx == -1) return "";
            line = line.Substring(idx + 1);
            idx = line.IndexOf("]");
            if (idx == -1) return "";
            zeuge = line.Substring(0, idx);
            idx = zeuge.IndexOf("4:<");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf("4>");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(0, idx);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            else
            {
                zeuge = zeuge.Substring(idx + 1);
            }
            idx = zeuge.IndexOf(",");
            if (idx != -1)
            {
                zeuge = zeuge.Substring(0, idx);
            }
            return zeuge;
    }

    private object GetZeuge4B(string line)
    {
            string zeuge;

            int idx = line.IndexOf("[");
            if (idx == -1) return "";
            line = line.Substring(idx + 1);
            idx = line.IndexOf("]");
            if (idx == -1) return "";
            zeuge = line.Substring(0, idx);
            idx = zeuge.IndexOf("4:<");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf("4>");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(0, idx);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            zeuge = zeuge.Substring(idx + 1);
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            else
            {
                zeuge = zeuge.Substring(idx + 1);
            }
            idx = zeuge.IndexOf(",");
            if (idx == -1) return "";
            else
            {
                zeuge = zeuge.Substring(idx + 1);
            }
            return zeuge;
    }

        private object GetComment(string line)
    {
      int idx = line.IndexOf("Beruf ");
      if (line.Contains("Nittmann"))
      {
        int i = 0;
        i++;
      }
      if (idx == -1)
      {
        idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf(",");
        line = line.Substring(idx + 1);
        idx = line.IndexOf("(");
        if (idx == -1)
        {
          if (line.Contains("U:"))
          {
            idx = line.IndexOf("U:");
            line = line.Substring(idx + 3);
            string str = "";
            if (!line.StartsWith("U:")) str = ", der Täufling ist ";
            line = line.Replace("U:", str);
            if (line.EndsWith(" ")) line = line.Substring(0, line.Length - 2);
            if (line.StartsWith(" ")) line = line.Substring(1, line.Length - 1);
            if (line.StartsWith("# ")) line = line.Substring(2);
            return line;
          }
          return "";
        }
        line = line.Substring(idx);
        if (line.Contains("("))
        {
          line = line.Replace("(", "");
        }
        if (line.Contains(")"))
        {
          line = line.Replace(")", "");
        }
        if (line.Contains("U:"))
        {
          string str = "";
          if (!line.StartsWith("U:")) str = ", der Täufling ist ";
          line = line.Replace("U:", str);
          if (line.EndsWith(" ")) line = line.Substring(0, line.Length - 2);
          if (line.StartsWith(" ")) line = line.Substring(1, line.Length - 1);
        }
        if (line.StartsWith("# ")) line = line.Substring(2);
        return line;
      }
      idx = line.IndexOf(") ");
      if (idx == -1)
      {
        return "";
      }
      line = line.Substring(idx + 1);
      if (line.Contains("("))
      {
        line = line.Replace("(", "");
      }
      if (line.Contains(")"))
      {
        line = line.Replace(")", "");
      }
      if (line.StartsWith(" ")) line = line.Substring(1, line.Length - 1);
      if (line.Contains("U:"))
      {
        string str = "";
        if (!line.StartsWith("U:")) str = ", der Täufling ist ";
        line = line.Replace("U:", str);
        if (line.EndsWith(" ")) line = line.Substring(0, line.Length - 2);
        if (line.StartsWith(" ")) line = line.Substring(1, line.Length - 1);
      }
      if (line.StartsWith("# ")) line = line.Substring(2);
      return line;
    }

    private void ThisAddIn_Startup(object sender, System.EventArgs e)
    {
#if BLA
      using (FileStream filestream = new FileStream("C:\\Users\\vissnh\\Downloads\\Domstadtl_1762_1786.txt", FileMode.Open, FileAccess.Read))
      {
        using (StreamReader reader = new StreamReader(filestream, Encoding.Default))
        {
          var line = reader.ReadLine();
          if (line.Contains("Sterbe"))
          {
            reader.Close();
            DisplayInExcelSterbe2();
            return;
          }
        }
      }
      using (FileStream filestream = new FileStream("D:\\Haeuser\\Do1742St.txt", FileMode.Open, FileAccess.Read))
      {
        using (StreamReader reader = new StreamReader(filestream, Encoding.Default))
        {
          var line = reader.ReadLine();
          if (line.Contains("Sterbe"))
          {
            reader.Close();
            DisplayInExcelSterbe();
            return;
          }
        }
      }
#endif
      using (FileStream filestream = new FileStream("C:\\Users\\vissnh\\Downloads\\647.txt", FileMode.Open, FileAccess.Read))
      {
        using (StreamReader reader = new StreamReader(filestream, Encoding.Default))
        {
          var line = reader.ReadLine();
          if (line.Contains("Hochzeit"))
          {
            reader.Close();
            DisplayInExcelMarry();
            return;
          }
        }
      }
     // DisplayInExcel();
    }

    private void DisplayInExcelSterbe()
    {
      var excelApp = this.Application;
      string kronland;
      string staat;
      string buchtyp;
      string ort;
      string ortdetail;
      string konfession;
      string buch;
      string year;
      string isdp;
      int num;
      // Add a new Excel workbook.
      excelApp.Workbooks.Add();
      excelApp.Visible = true;
      excelApp.Range["A1"].Value = "KRONLAND";
      excelApp.Range["B1"].Value = "Heutiger_Staat";
      excelApp.Range["C1"].Value = "BuchTyp";
      excelApp.Range["D1"].Value = "Ort_Matrikenführung";
      excelApp.Range["E1"].Value = "Ort_Detail";
      excelApp.Range["F1"].Value = "KONFESSION";
      excelApp.Range["G1"].Value = "Buch";
      excelApp.Range["H1"].Value = "STERBE_ORT";
      excelApp.Range["I1"].Value = "XSEITE";
      excelApp.Range["J1"].Value = "Sterbe_DATUM_JAHR";
      excelApp.Range["K1"].Value = "SterbeDATUM_MONAT";
      excelApp.Range["L1"].Value = "SterbeDATUM_TAG";
      excelApp.Range["M1"].Value = "Beerdigung_DATUM_JAHR";
      excelApp.Range["N1"].Value = "Beerdigung_DATUM_MONAT";
      excelApp.Range["O1"].Value = "Beerdigung_DATUM_TAG";
      excelApp.Range["P1"].Value = "Gestorbener_V";
      excelApp.Range["Q1"].Value = "Gestorbener_F";
      excelApp.Range["R1"].Value = "Gestorber_Maedchenname";
      excelApp.Range["S1"].Value = "Gestorben_ALTER_JAHRE";
      excelApp.Range["T1"].Value = "Gestorben_ALTER_Monate";
      excelApp.Range["U1"].Value = "Gestorben_ALTER_Tage";
      excelApp.Range["V1"].Value = "Gestorbener_S";
      excelApp.Range["W1"].Value = "Gestorbener_B";
      excelApp.Range["X1"].Value = "Ehe_W";
      excelApp.Range["Y1"].Value = "Ehe_V";
      excelApp.Range["Z1"].Value = "Ehe_F";
      excelApp.Range["AA1"].Value = "Ehe_S";
      excelApp.Range["AB1"].Value = "Ehe_B";
      excelApp.Range["AC1"].Value = "Ehe_W";
      excelApp.Range["AD1"].Value = "Gestorbener_VATER_V";
      excelApp.Range["AE1"].Value = "Gestorbener_VATER_F";
      excelApp.Range["AF1"].Value = "Gestorbener_VATER_S";
      excelApp.Range["AG1"].Value = "Gestorbener_VATER_B";
      excelApp.Range["AH1"].Value = "Gestorbener_VATER_W";
      excelApp.Range["AI1"].Value = "Gestorbener_Mutter_V";
      excelApp.Range["AJ1"].Value = "Gestorbener_Mutter_F";
      excelApp.Range["AK1"].Value = "Gestorbener_Mutter_S";
      excelApp.Range["AL1"].Value = "Beerdigungsort";
      excelApp.Range["AM1"].Value = "Todesursache";
      excelApp.Range["AN1"].Value = "Sonstiges";
      excelApp.Range["AO1"].Value = "URL";
      num = 2;
      using (FileStream filestream = new FileStream("D:\\Haeuser\\Do1742St.txt", FileMode.Open, FileAccess.Read))
      {
        using (StreamReader reader = new StreamReader(filestream, Encoding.Default))
        {
          reader.ReadLine();
          kronland = reader.ReadLine();
          staat = reader.ReadLine();
          buchtyp = reader.ReadLine();
          ort = reader.ReadLine();
          ortdetail = reader.ReadLine();
          konfession = reader.ReadLine();
          buch = reader.ReadLine();
          year = "";
          isdp = "";
          while (!reader.EndOfStream)
          {
            var line = reader.ReadLine();
            if (line.Length == 0)
            {
              continue;
            }
            if (line.Equals(" "))
            {
              continue;
            }
            if ((line.Length.Equals(4)) && (line.Contains("DP") == false))
            {
              year = line;
              continue;
            }
            if (line.StartsWith("DP"))
            {
              line = line.Substring(3);
              isdp = line;
              continue;
            }
            excelApp.Range["A" + num].Value = kronland;
            excelApp.Range["B" + num].Value = staat;
            excelApp.Range["C" + num].Value = buchtyp;
            excelApp.Range["D" + num].Value = ort;
            excelApp.Range["E" + num].Value = ortdetail;
            excelApp.Range["F" + num].Value = konfession;
            excelApp.Range["G" + num].Value = buch;
            excelApp.Range["J" + num].Value = year;
            excelApp.Range["I" + num].Value = isdp;

            int idx = line.IndexOf(".");
            int idx2 = line.IndexOf(",");
            if (idx < idx2)
            {
              line = "-," + line;
            }

            excelApp.Range["H" + num].Value = GetOrtSterbe(line);
            excelApp.Range["AN" + num].Value = GetDeathComment(line);
            excelApp.Range["K" + num].Value = GetMonat(line);
            excelApp.Range["L" + num].Value = GetTag(line);
            excelApp.Range["P" + num].Value = GetVorname(line);
            excelApp.Range["S" + num].Value = GetAgeYears(line);
            excelApp.Range["T" + num].Value = GetAgeMonths(line);
            excelApp.Range["U" + num].Value = GetAgeDays(line);
            if ((line.Contains("(vidua")) || (line.Contains("(Witwe")) || (line.Contains("(Ehefrau")))
            {
              excelApp.Range["Y" + num].Value = GetVaterVorname(line);
              excelApp.Range["Z" + num].Value = GetVaterNachname(line);
            }
            else
            {
              if (GetVaterVorname(line).Equals("-"))
              {
                excelApp.Range["Q" + num].Value = GetVaterNachname(line);
              }
              else
              {
                excelApp.Range["AD" + num].Value = GetVaterVorname(line);
                excelApp.Range["AE" + num].Value = GetVaterNachname(line);
              }
            }
            if (line.Contains("(geboren "))
            {
              excelApp.Range["AD" + num].Value = GetVaterVorname2(line);
              excelApp.Range["AE" + num].Value = GetVaterNachname2(line);
            }
            if (line.Contains("(geboren2 "))
            {
              excelApp.Range["AD" + num].Value = GetVaterVorname2(line);
              excelApp.Range["AE" + num].Value = GetVaterNachname2(line);
            }
            if ((line.Contains("(vidua")) || (line.Contains("(Witwe")) || (line.Contains("(Ehefrau")))
            {
              if (
                (((string)GetDeathBeruf(line)).EndsWith("in")) ||
                (((string)GetDeathBeruf(line)).Equals("Inweib")) ||
                (((string)GetDeathBeruf(line)).Equals("ledig")))
              {
                excelApp.Range["W" + num].Value = GetDeathBeruf(line);
              }
              else
              {
                excelApp.Range["AB" + num].Value = GetDeathBeruf(line);
              }

            }
            else
            {
              if (!GetVaterVorname(line).Equals("-"))
              {
                excelApp.Range["AG" + num].Value = GetDeathBeruf(line);
              }
              else
              {
                if (GetAgeYearsInt(line) < 18)
                {
                  excelApp.Range["AG" + num].Value = GetDeathBeruf(line);
                }
                else
                {
                  excelApp.Range["W" + num].Value = GetDeathBeruf(line);
                }

              }
            }
            excelApp.Range["AI" + num].Value = GetMotherVorname(line);
            excelApp.Range["AJ" + num].Value = GetMotherNachname(line);
            num++;
          }


        }
      }
    }

    private string GetVaterVorname2(string line)
    {
      int idx;
      idx = line.IndexOf("(geboren2 ");
      if (idx == -1)
      {
        return "";
      }
      line = line.Substring(idx + 10);
      idx = line.IndexOf(" ");
      line = line.Substring(0, idx);

      return line;
    }

    private string GetVaterNachname2(string line)
    {
      int idx;
      idx = line.IndexOf("(geboren2 ");
      if (idx == -1)
      {
        idx = line.IndexOf("(geboren ");
        line = line.Substring(idx + 9);
        idx = line.IndexOf(" ");
        if (idx == -1) idx = line.IndexOf(")");
        line = line.Substring(0, idx);
        return line;
      }
      line = line.Substring(idx + 10);
      idx = line.IndexOf(" ");
      line = line.Substring(idx + 1);
      idx = line.IndexOf(" ");
      if (idx == -1) idx = line.IndexOf(")");
      line = line.Substring(0, idx);
      if (line.Contains(","))
      {
        idx = line.IndexOf(",");
        line = line.Substring(0, idx);
      }

      return line;
    }

    private void DisplayInExcelSterbe2()
    {
      var excelApp = this.Application;
      string kronland;
      string staat;
      string buchtyp;
      string ort;
      string ortdetail;
      string konfession;
      string buch;
      string year;
      string isdp;
      int num;
      // Add a new Excel workbook.
      excelApp.Workbooks.Add();
      excelApp.Visible = true;
      excelApp.Range["A1"].Value = "KRONLAND";
      excelApp.Range["B1"].Value = "Heutiger_Staat";
      excelApp.Range["C1"].Value = "BuchTyp";
      excelApp.Range["D1"].Value = "Ort_Matrikenführung";
      excelApp.Range["E1"].Value = "Ort_Detail";
      excelApp.Range["F1"].Value = "KONFESSION";
      excelApp.Range["G1"].Value = "Buch";
      excelApp.Range["H1"].Value = "STERBE_ORT";
      excelApp.Range["I1"].Value = "XSEITE";
      excelApp.Range["J1"].Value = "Sterbe_DATUM_JAHR";
      excelApp.Range["K1"].Value = "SterbeDATUM_MONAT";
      excelApp.Range["L1"].Value = "SterbeDATUM_TAG";
      excelApp.Range["M1"].Value = "Beerdigung_DATUM_JAHR";
      excelApp.Range["N1"].Value = "Beerdigung_DATUM_MONAT";
      excelApp.Range["O1"].Value = "Beerdigung_DATUM_TAG";
      excelApp.Range["P1"].Value = "Gestorbener_V";
      excelApp.Range["Q1"].Value = "Gestorbener_F";
      excelApp.Range["R1"].Value = "Gestorber_Maedchenname";
      excelApp.Range["S1"].Value = "Gestorben_ALTER_JAHRE";
      excelApp.Range["T1"].Value = "Gestorben_ALTER_Monate";
      excelApp.Range["U1"].Value = "Gestorben_ALTER_Tage";
      excelApp.Range["V1"].Value = "Gestorbener_S";
      excelApp.Range["W1"].Value = "Gestorbener_B";
      excelApp.Range["X1"].Value = "Ehe_W";
      excelApp.Range["Y1"].Value = "Ehe_V";
      excelApp.Range["Z1"].Value = "Ehe_F";
      excelApp.Range["AA1"].Value = "Ehe_S";
      excelApp.Range["AB1"].Value = "Ehe_B";
      excelApp.Range["AC1"].Value = "Ehe_W";
      excelApp.Range["AD1"].Value = "Gestorbener_VATER_V";
      excelApp.Range["AE1"].Value = "Gestorbener_VATER_F";
      excelApp.Range["AF1"].Value = "Gestorbener_VATER_S";
      excelApp.Range["AG1"].Value = "Gestorbener_VATER_B";
      excelApp.Range["AH1"].Value = "Gestorbener_VATER_W";
      excelApp.Range["AI1"].Value = "Gestorbener_Mutter_V";
      excelApp.Range["AJ1"].Value = "Gestorbener_Mutter_F";
      excelApp.Range["AK1"].Value = "Gestorbener_Mutter_S";
      excelApp.Range["AL1"].Value = "Beerdigungsort";
      excelApp.Range["AM1"].Value = "Todesursache";
      excelApp.Range["AN1"].Value = "Sonstiges";
      excelApp.Range["AO1"].Value = "URL";
      num = 2;
      using (FileStream filestream = new FileStream("C:\\Users\\vissnh\\Downloads\\Domstadtl_1762_1786.txt", FileMode.Open, FileAccess.Read))
      {
        using (StreamReader reader = new StreamReader(filestream, Encoding.Default))
        {
          reader.ReadLine();
          kronland = reader.ReadLine();
          staat = reader.ReadLine();
          buchtyp = reader.ReadLine();
          ort = reader.ReadLine();
          ortdetail = reader.ReadLine();
          konfession = reader.ReadLine();
          buch = reader.ReadLine();
          year = "";
          isdp = "";
          while (!reader.EndOfStream)
          {
            var line = reader.ReadLine();
            if (line.Length == 0)
            {
              continue;
            }
            if (line.Equals(" "))
            {
              continue;
            }
            if ((line.Length.Equals(4)) && (line.Contains("DP") == false))
            {
              year = line;
              continue;
            }
            if (line.StartsWith("DP"))
            {
              line = line.Substring(3);
              isdp = line;
              continue;
            }
            excelApp.Range["A" + num].Value = kronland;
            excelApp.Range["B" + num].Value = staat;
            excelApp.Range["C" + num].Value = buchtyp;
            excelApp.Range["D" + num].Value = ort;
            excelApp.Range["E" + num].Value = ortdetail;
            excelApp.Range["F" + num].Value = konfession;
            excelApp.Range["G" + num].Value = buch;
            excelApp.Range["J" + num].Value = year;
            excelApp.Range["I" + num].Value = isdp;

            int idx = line.IndexOf(".");
            int idx2 = line.IndexOf(",");
            if (idx < idx2)
            {
              line = "-," + line;
            }

            excelApp.Range["H" + num].Value = GetOrtSterbe(line);
            excelApp.Range["AN" + num].Value = GetDeathComment(line);
            excelApp.Range["K" + num].Value = GetMonat(line);
            excelApp.Range["L" + num].Value = GetTag(line);
            excelApp.Range["P" + num].Value = GetVorname(line);
            excelApp.Range["S" + num].Value = GetAgeYears(line);
            excelApp.Range["T" + num].Value = GetAgeMonths(line);
            excelApp.Range["U" + num].Value = GetAgeDays(line);
            if ((line.Contains("(vidua")) || (line.Contains("(Witwe")) || (line.Contains("(Ehefrau")))
            {
              excelApp.Range["Y" + num].Value = GetVaterVorname(line);
              excelApp.Range["Z" + num].Value = GetVaterNachname(line);
            }
            else
            {
              if (GetVaterVorname(line).Equals("-"))
              {
                excelApp.Range["Q" + num].Value = GetVaterNachname(line);
              }
              else
              {
                excelApp.Range["AD" + num].Value = GetVaterVorname(line);
                excelApp.Range["AE" + num].Value = GetVaterNachname(line);
              }
            }
            if (line.Contains("(Die Verstorbene war geb. "))
            {
              excelApp.Range["AE" + num].Value = GetBirthname(line);
            }
            if ((line.Contains("(vidua")) || (line.Contains("(Witwe")) || (line.Contains("(Ehefrau")))
            {
              if (
                (((string)GetDeathBeruf(line)).EndsWith("in")) ||
                (((string)GetDeathBeruf(line)).Equals("Inweib")) ||
                (((string)GetDeathBeruf(line)).Equals("ledig")))
              {
                excelApp.Range["W" + num].Value = GetDeathBeruf(line);
              }
              else
              {
                excelApp.Range["AB" + num].Value = GetDeathBeruf(line);
              }

            }
            else
            {
              if (!GetVaterVorname(line).Equals("-"))
              {
                excelApp.Range["AG" + num].Value = GetDeathBeruf(line);
              }
              else
              {
                if (GetAgeYearsInt(line) < 18)
                {
                  excelApp.Range["AG" + num].Value = GetDeathBeruf(line);
                }
                else
                {
                  excelApp.Range["W" + num].Value = GetDeathBeruf(line);
                }

              }
            }
            excelApp.Range["AI" + num].Value = GetMotherVorname(line);
            excelApp.Range["AJ" + num].Value = GetMotherNachname(line);
            if (line.Contains("(Mutter von"))
            {
              excelApp.Range["AI" + num].Value = GetMotherPrename(line);
              excelApp.Range["AJ" + num].Value = GetBirthname(line);
            }
            num++;
          }


        }
      }
    }

    private string GetMotherPrename(string line)
    {
      int pos;
      pos = line.IndexOf("(Mutter von ");
      string tmp = line.Substring(pos);
      pos = tmp.IndexOf("war ");
      tmp = tmp.Substring(pos + 4);
      pos = tmp.IndexOf(",");
      tmp = tmp.Substring(0, pos);
      return tmp;
    }

    private string GetBirthname(string line)
    {
      int pos = line.IndexOf("Die Verstorbene war geb. ");
      if (pos == -1)
      {
        pos = line.IndexOf("(Mutter von");
        if (pos != -1)
        {
          pos = line.IndexOf("geb. ");
          string tmp = line.Substring(pos + 5);
          pos = tmp.IndexOf(",");
          if (pos == -1)
          {
            pos = tmp.IndexOf(")");
          }
          tmp = tmp.Substring(0, pos);
          return tmp;
        }
        return "";
      }
      string temp = line.Substring(pos + 25);
      pos = temp.IndexOf(")");
      temp = temp.Substring(0, pos);
      if (temp.Contains(","))
      {
        pos = temp.IndexOf(",");
        temp = temp.Substring(0, pos);
      }
      return temp;
    }

    private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
    {
    }

    #region VSTO generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InternalStartup()
    {
      this.Startup += new System.EventHandler(ThisAddIn_Startup);
      this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
    }

    #endregion
  }
}
