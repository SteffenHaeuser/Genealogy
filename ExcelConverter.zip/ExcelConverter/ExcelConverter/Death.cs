﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Windows.Forms;

namespace ExcelConverter
{
    public class Death
    {
        private static string GetOrtSterbe(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf(",");
                string tmp = line.Substring(0, idx);

                idx = line.IndexOf("(");
                if (idx != -1)
                {
                    string bck;
                    int idx2 = 0;
                    line = line.Substring(idx + 1);
                    if (line.Contains("vidua,"))
                    {
                        line = line.Substring(7);
                        if (line.IndexOf("#") == -1)
                        {
                            return tmp;
                        }
                        idx = line.IndexOf("#") + 1;
                        line = line.Substring(idx);
                        idx = line.IndexOf(",");
                        if (idx == -1)
                        {
                            idx = line.IndexOf(")");
                            line = line.Substring(0, idx);
                        }
                        idx = line.IndexOf(",");
                        if (idx != -1)
                        {
                            line = line.Substring(0, idx);
                        }
                        else
                        {
                            idx = line.IndexOf(")");
                            if (idx != -1)
                            {
                                line = line.Substring(0, idx);
                            }
                        }
                        idx = line.IndexOf(")");
                        if (idx != -1)
                        {
                            line = line.Substring(0, idx);
                        }
                        tmp = tmp + " No. " + line;
                    }
                    else if (line.Contains("Tochter,"))
                    {
                        line = line.Substring(8);
                        if (line.IndexOf("#") == -1)
                        {
                            return tmp;
                        }
                        idx = line.IndexOf("#") + 1;
                        line = line.Substring(idx);
                        idx = line.IndexOf(",");
                        if (idx == -1)
                        {
                            idx = line.IndexOf(")");
                            line = line.Substring(0, idx);
                        }
                        else
                        {
                            line = line.Substring(0, idx);
                        }
                        if (idx != -1)
                        {
                            line = line.Substring(0, idx);
                        }
                        else
                        {
                            idx = line.IndexOf(")");
                            if (idx != -1)
                            {
                                line = line.Substring(0, idx);
                            }
                        }
                        idx = line.IndexOf(")");
                        if (idx != -1)
                        {
                            line = line.Substring(0, idx);
                        }
                        tmp = tmp + " No. " + line;
                    }
                    else if (line.Contains("Ehefrau,"))
                    {
                        line = line.Substring(8);
                        if (line.IndexOf("#") == -1)
                        {
                            return tmp;
                        }
                        idx = line.IndexOf("#") + 1;
                        line = line.Substring(idx);
                        idx = line.IndexOf(",");
                        if (idx == -1)
                        {
                            idx = line.IndexOf(")");
                            line = line.Substring(0, idx);
                        }
                        else
                        {
                            line = line.Substring(0, idx);
                        }
                        if (idx != -1)
                        {
                            line = line.Substring(0, idx);
                        }
                        else
                        {
                            idx = line.IndexOf(")");
                            if (idx != -1)
                            {
                                line = line.Substring(0, idx);
                            }
                        }
                        idx = line.IndexOf(")");
                        if (idx != -1)
                        {
                            line = line.Substring(0, idx);
                        }
                        tmp = tmp + " No. " + line;
                    }
                    else if (line.Contains("Witwe,"))
                    {
                        line = line.Substring(6);
                        if (line.IndexOf("#") == -1)
                        {
                            return tmp;
                        }
                        idx = line.IndexOf("#") + 1;
                        line = line.Substring(idx);
                        idx = line.IndexOf(",");
                        if (idx == -1)
                        {
                            idx = line.IndexOf(")");
                            line = line.Substring(0, idx);
                        }
                        else
                        {
                            line = line.Substring(0, idx);
                        }
                        if (idx != -1)
                        {
                            line = line.Substring(0, idx);
                        }
                        else
                        {
                            if (line.StartsWith("#") == false)
                            {
                                return tmp;
                            }
                            idx = line.IndexOf(")");
                            if (idx != -1)
                            {
                                line = line.Substring(0, idx);
                            }
                        }
                        idx = line.IndexOf(")");
                        if (idx != -1)
                        {
                            line = line.Substring(0, idx);
                        }
                        tmp = tmp + " No. " + line;
                    }
                    else
                    {
                        if (line.IndexOf("#") == -1)
                        {
                            return tmp;
                        }
                        idx = line.IndexOf("#") + 1;
                        line = line.Substring(idx);
                        idx = line.IndexOf(",");
                        if (idx == -1)
                        {
                            idx = line.IndexOf(")");
                            line = line.Substring(0, idx);
                        }
                        else
                        {
                            line = line.Substring(0, idx);
                        }
                        if (idx != -1)
                        {
                            line = line.Substring(0, idx);
                        }
                        else
                        {
                            idx = line.IndexOf(")");
                            if (idx != -1)
                            {
                                line = line.Substring(0, idx);
                            }
                        }
                        idx = line.IndexOf(")");
                        if (idx != -1)
                        {
                            line = line.Substring(0, idx);
                        }
                        tmp = tmp + " No. " + line;

                    }
                }

                if (tmp.StartsWith("- "))
                {
                    tmp = tmp.Replace("- ", "");
                }

                if (tmp.EndsWith(" No. "))
                {
                    tmp = tmp.Replace(" No. ", "");
                }

                return tmp;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetOrtDeath() with Line " + origLine;
                return "";
            }
        }
        private static object GetDeathComment(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf(")");
                string bck;
                bck = line.Substring(idx + 1);
                if (bck.Contains("("))
                {
                    bck = line.Substring(line.IndexOf("(") + 1);
                    idx = bck.IndexOf(")");
                    bck = bck.Substring(idx);
                    idx = bck.IndexOf("(");
                    bck = bck.Substring(idx + 1);
                    bck = bck.Replace(")", "");
                    idx = bck.IndexOf("U:");
                    if (idx != -1)
                    {
                        bck = bck.Substring(0, idx);
                    }

                    if (bck.StartsWith("geboren"))
                    {
                        if (bck.Contains(","))
                        {
                            idx = bck.IndexOf(",");
                            bck = bck.Substring(idx + 1);
                        }
                        else
                        {
                            bck = "";
                        }
                    }
                    return bck;
                }

                return "";
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetDeathComment() with Line " + origLine;
                return "";
            }
        }
        private static object GetAgeYears(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(" ");
                if (idx != -1)
                {
                    line = line.Substring(0, idx);
                }
                if (line.Contains("y"))
                {
                    idx = line.IndexOf("y");
                    line = line.Substring(0, idx);
                    return line;
                }
                if (line.Contains("d"))
                {
                    return "";
                }
                if (line.Contains("m"))
                {
                    return "";
                }
                if (line.Contains("w"))
                {
                    return "";
                }
                return line;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetAgeYears() with Line " + origLine;
                return "";
            }
        }

        private static object GetAgeMonths(string line)
        {
            string origLine = line;
            try
            {
                bool isNr = false;
                int idx = line.IndexOf(",");
                int num = 0;
                string bck = "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(" ");
                if (idx != -1)
                {
                    line = line.Substring(0, idx);
                }
                if (line.Contains("w"))
                {
                    if (line.Contains("y"))
                    {
                        idx = line.IndexOf("y");
                        line = line.Substring(idx + 1);
                    }
                    idx = line.IndexOf("w");
                    if (idx != -1)
                    {
                        bck = line.Substring(0, idx);
                    }
                    if (bck.Contains("#") == false)
                    {
                        num = Int32.Parse(bck);
                        num = num * 7;
                        num = num / 30;
                    }
                    else
                    {
                        bck = bck.Replace("#", "");
                        isNr = true;
                        num = Int32.Parse(bck);
                        num = num * 7;
                        num = num / 30;
                    }
                }
                if (line.Contains("m"))
                {
                    if (line.Contains("y"))
                    {
                        idx = line.IndexOf("y");
                        line = line.Substring(idx + 1);
                    }
                    idx = line.IndexOf("m");
                    bck = line.Substring(0, idx);
                    if (bck.Contains("#") == false)
                    {
                        num = num + Int32.Parse(bck);
                    }
                    else
                    {
                        bck = bck.Replace("#", "");
                        num = num + Int32.Parse(bck);
                        isNr = true;
                    }
                }
                if (num == 0) return "";

                if (isNr)
                {
                    return num + "#";
                }
                return num.ToString();
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetAgeMonths() with Line " + origLine;
                return "";
            }
        }

        private static object GetAgeDays(string line)
        {
            string origLine = line;
            try
            {
                bool isNr = false;
                int idx = line.IndexOf(",");
                int num = 0;
                string bck = "";
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(",");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(" ");
                if (idx != -1)
                {
                    line = line.Substring(0, idx);
                }
                if (line.Contains("w"))
                {
                    if (line.Contains("y"))
                    {
                        idx = line.IndexOf("y");
                        line = line.Substring(idx + 1);
                    }
                    if (line.Contains("m"))
                    {
                        idx = line.IndexOf("m");
                        line = line.Substring(idx + 1);
                    }
                    idx = line.IndexOf("w");
                    if (idx != -1)
                    {
                        bck = line.Substring(0, idx);
                    }
                    if (bck.Contains("#") == false)
                    {
                        int num2 = 0;
                        num = Int32.Parse(bck);
                        num2 = num;
                        num = num * 7;
                        num = num / 30;
                        num = (num2 - ((num * 30) / 7)) * 7;
                    }
                    else
                    {
                        int num2 = 0;
                        bck = bck.Replace("#", "");
                        num = Int32.Parse(bck);
                        num2 = num;
                        num = num * 7;
                        num = num / 30;
                        num = (num2 - ((num * 30) / 7)) * 7;
                        isNr = true;
                    }
                }
                if (line.Contains("d"))
                {
                    if (line.Contains("y"))
                    {
                        idx = line.IndexOf("y");
                        line = line.Substring(idx + 1);
                    }
                    if (line.Contains("m"))
                    {
                        idx = line.IndexOf("m");
                        line = line.Substring(idx + 1);
                    }
                    if (line.Contains("w"))
                    {
                        idx = line.IndexOf("w");
                        line = line.Substring(idx + 1);
                    }
                    idx = line.IndexOf("d");
                    bck = line.Substring(0, idx);
                    if (bck.Contains("#") == false)
                    {
                        num = num + Int32.Parse(bck);
                    }
                    else
                    {
                        bck = bck.Replace("#", "");
                        num = num + Int32.Parse(bck);
                        isNr = true;
                    }
                }
                if (num == 0) return "";

                if (isNr)
                {
                    return num + "#";
                }

                return num.ToString();
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetAgeDays() with Line " + origLine;
                return "";
            }
        }
        private static string GetVaterVorname2(string line)
        {
            string origLine = line;
            try
            {
                int idx;
                idx = line.IndexOf("(geboren2 ");
                if (idx == -1)
                {
                    return "";
                }
                line = line.Substring(idx + 10);
                idx = line.IndexOf(" ");
                line = line.Substring(0, idx);

                return line;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetVaterVorname2() with Line " + origLine;
                return "";
            }
        }

        private static string GetVaterNachname2(string line)
        {
            string origLine = line;
            try
            {
                int idx;
                idx = line.IndexOf("(geboren2 ");
                if (idx == -1)
                {
                    idx = line.IndexOf("(geboren ");
                    line = line.Substring(idx + 9);
                    idx = line.IndexOf(" ");
                    if (idx == -1) idx = line.IndexOf(")");
                    line = line.Substring(0, idx);
                    return line;
                }
                line = line.Substring(idx + 10);
                idx = line.IndexOf(" ");
                line = line.Substring(idx + 1);
                idx = line.IndexOf(" ");
                if (idx == -1) idx = line.IndexOf(")");
                line = line.Substring(0, idx);
                if (line.Contains(","))
                {
                    idx = line.IndexOf(",");
                    line = line.Substring(0, idx);
                }

                return line;
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetVaterNachname2() with Line " + origLine;
                return "";
            }
        }
        private static object GetDeathBeruf2(string line)
        {
            string origLine = line;
            try
            {
                string bck = "";
                int idx = line.IndexOf("(");
                if (idx != -1)
                {
                    line = line.Substring(idx + 1);
                    idx = line.IndexOf(")");
                    line = line.Substring(0, idx);
                    idx = line.IndexOf(",");
                    if (idx == -1)
                    {
                        if (line.Contains("#"))
                        {
                            return "";
                        }
                        if (line.StartsWith("Ehefrau")) line = "";
                        if (line.StartsWith("vidua")) line = "";
                        if (line.StartsWith("Witwe")) line = "";
                        if (line.StartsWith("Tochter")) line = "";
                        return line;
                    }
                    bck = line;
                    if (bck.StartsWith("vidua,"))
                    {
                        line = bck.Substring(6);
                        idx = line.IndexOf(",");
                    }
                    if (bck.StartsWith("Witwe,"))
                    {
                        line = bck.Substring(6);
                        idx = line.IndexOf(",");
                    }
                    if (bck.StartsWith("Tochter,"))
                    {
                        line = bck.Substring(8);
                        idx = line.IndexOf(",");
                    }
                    if (bck.StartsWith("Ehefrau,"))
                    {
                        line = bck.Substring(8);
                        idx = line.IndexOf(",");
                    }
                    line = line.Substring(idx + 1);
                    line = line.Replace(" #", "#");
                    if ((line.StartsWith("#")) && (line != "#"))
                    {
                        if (idx == -1) return "";
                        line = bck.Substring(0, idx);


                        return line;
                    }
                    if (line == "#")
                    {
                        return line;
                    }
                    idx = line.IndexOf(",");
                    if (idx == -1)
                    {
                        if (line.Contains("#"))
                        {
                            return "";
                        }
                        return line;
                    }
                    if (line.StartsWith("#"))
                    {
                        line = line.Substring(idx + 1);
                        return line;
                    }
                    line = line.Substring(0, idx);
                    return line;
                }
                return "";
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetDeathBeruf2() with Line " + origLine;
                return "";
            }
        }

        private static object GetDeathBeruf(string line)
        {
            string bck = (string)Death.GetDeathBeruf2(line);
            bck = bck.Replace("Beruf ", "");
            return bck;
        }
        private static int GetAgeYearsInt(string line)
        {
            string age;
            string origLine = line;
            try
            {
                age = (string)Death.GetAgeYears(line);
                return Int32.Parse(age);
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetAgeYearsInt() with Line " + origLine;
                return 0;
            }
        }
        private static object GetMotherVorname(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf("U:");
                if (idx == -1) return "";
                line = line.Substring(idx + 2);
                if (line.Contains("unehelich"))
                {
                    idx = line.IndexOf("unehelich");
                    line = line.Substring(idx + 9);
                    idx = line.IndexOf("von ");
                    line = line.Substring(idx + 4);
                    idx = line.IndexOf(" aus");
                    if (idx == -1)
                    {
                        idx = line.IndexOf(" ");
                        line = line.Substring(0, idx);
                        return line;
                    }
                    else
                    {
                        line = line.Substring(0, idx);

                        idx = line.IndexOf(" ");
                        line = line.Substring(0, idx);
                        return line;
                    }
                }
                if (line.Contains("Kind von"))
                {
                    idx = line.IndexOf("Kind ");
                    line = line.Substring(idx + 5);
                    idx = line.IndexOf("von ");
                    line = line.Substring(idx + 4);
                    idx = line.IndexOf(" aus");
                    if (idx == -1)
                    {
                        idx = line.IndexOf(" ");
                        line = line.Substring(0, idx);
                        return line;
                    }
                    else
                    {
                        line = line.Substring(0, idx);

                        idx = line.IndexOf(" ");
                        line = line.Substring(0, idx);
                        return line;
                    }
                }
                if (line.Contains("Kind ist Tochter"))
                {
                    idx = line.IndexOf("Kind ist Tochter");
                    line = line.Substring(idx + 16);
                    idx = line.IndexOf("der ");
                    line = line.Substring(idx + 4);
                    idx = line.IndexOf(" aus");
                    if (idx == -1)
                    {
                        idx = line.IndexOf(" ");
                        line = line.Substring(0, idx);
                        return line;
                    }
                    else
                    {
                        line = line.Substring(0, idx);

                        idx = line.IndexOf(" ");
                        line = line.Substring(0, idx);
                        return line;
                    }
                }
                if (line.Contains("Kind ist Sohn"))
                {
                    idx = line.IndexOf("Kind ist Sohn");
                    line = line.Substring(idx + 13);
                    idx = line.IndexOf("der ");
                    line = line.Substring(idx + 4);
                    idx = line.IndexOf(" aus");
                    if (idx == -1)
                    {
                        idx = line.IndexOf(" ");
                        line = line.Substring(0, idx);
                        return line;
                    }
                    else
                    {
                        line = line.Substring(0, idx);

                        idx = line.IndexOf(" ");
                        line = line.Substring(0, idx);
                        return line;
                    }
                }
                return "";
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetMotherVorname() with Line " + origLine;
                return 0;
            }
        }

        private static object GetMotherNachname(string line)
        {
            string origLine = line;
            try
            {
                int idx = line.IndexOf("U:");
                if (idx == -1) return "";
                line = line.Substring(idx + 2);
                if (line.Contains("unehelich"))
                {
                    idx = line.IndexOf("unehelich");
                    line = line.Substring(idx + 9);
                    idx = line.IndexOf("von ");
                    line = line.Substring(idx + 4);
                    idx = line.IndexOf(" aus");
                    if (idx == -1)
                    {
                        idx = line.IndexOf(" ");
                        line = line.Substring(idx + 1);
                        return line;
                    }
                    else
                    {
                        line = line.Substring(0, idx);

                        idx = line.IndexOf(" ");
                        line = line.Substring(idx + 1);
                        return line;
                    }
                }
                if (line.Contains("Kind von"))
                {
                    idx = line.IndexOf("Kind ");
                    line = line.Substring(idx + 5);
                    idx = line.IndexOf("von ");
                    line = line.Substring(idx + 4);
                    idx = line.IndexOf(" aus");
                    if (idx == -1)
                    {
                        idx = line.IndexOf(" ");
                        line = line.Substring(idx + 1);
                        return line;
                    }
                    else
                    {
                        line = line.Substring(0, idx);

                        idx = line.IndexOf(" ");
                        line = line.Substring(idx + 1);
                        return line;
                    }
                }
                if (line.Contains("Kind ist Tochter"))
                {
                    idx = line.IndexOf("Kind ist Tochter");
                    line = line.Substring(idx + 16);
                    idx = line.IndexOf("der ");
                    line = line.Substring(idx + 4);
                    idx = line.IndexOf(" aus");
                    if (idx == -1)
                    {
                        idx = line.IndexOf(" ");
                        line = line.Substring(idx + 1);
                        return line;
                    }
                    else
                    {
                        line = line.Substring(0, idx);

                        idx = line.IndexOf(" ");
                        line = line.Substring(idx + 1);
                        return line;
                    }
                }
                if (line.Contains("Kind ist Sohn"))
                {
                    idx = line.IndexOf("Kind ist Sohn");
                    line = line.Substring(idx + 13);
                    idx = line.IndexOf("der ");
                    line = line.Substring(idx + 4);
                    idx = line.IndexOf(" aus");
                    if (idx == -1)
                    {
                        idx = line.IndexOf(" ");
                        line = line.Substring(idx + 1);
                        return line;
                    }
                    else
                    {
                        line = line.Substring(0, idx);

                        idx = line.IndexOf(" ");
                        line = line.Substring(idx + 1);
                        return line;
                    }
                }
                return "";
            }
            catch
            {
                Marriage.ErrorString = "Exception in GetMotherNachname() with Line " + origLine;
                return 0;
            }
        }


        public static void DisplayInExcelSterbe(Excel.Application excelData, String inputFilename, Label labStatusValue)
        {
            string kronland;
            string staat;
            string buchtyp;
            string ort;
            string ortdetail;
            string konfession;
            string buch;
            string genealogist;
            string year;
            string isdp;
            int num;
            var excelApp = excelData;

            var sheet = excelData.Workbooks[1].Sheets[1];
            sheet.Cells[1,1].Value = "KRONLAND";
            sheet.Cells[1, 2].Value = "Heutiger_Staat";
            sheet.Cells[1, 3].Value = "BuchTyp";
            sheet.Cells[1, 4].Value = "Ort_Matrikenführung";
            sheet.Cells[1, 5].Value = "Ort_Detail";
            sheet.Cells[1, 6].Value = "KONFESSION";
            sheet.Cells[1, 7].Value = "Buch";
            sheet.Cells[1, 8].Value = "STERBE_ORT";
            sheet.Cells[1, 9].Value = "XSEITE";
            sheet.Cells[1, 10].Value = "Sterbe_DATUM_JAHR";
            sheet.Cells[1, 11].Value = "SterbeDATUM_MONAT";
            sheet.Cells[1, 12].Value = "SterbeDATUM_TAG";
            sheet.Cells[1, 13].Value = "Beerdigung_DATUM_JAHR";
            sheet.Cells[1, 14].Value = "Beerdigung_DATUM_MONAT";
            sheet.Cells[1, 15].Value = "Beerdigung_DATUM_TAG";
            sheet.Cells[1, 16].Value = "Gestorbener_V";
            sheet.Cells[1, 17].Value = "Gestorbener_F";
            sheet.Cells[1, 18].Value = "Gestorber_Maedchenname";
            sheet.Cells[1, 19].Value = "Gestorben_ALTER_JAHRE";
            sheet.Cells[1, 20].Value = "Gestorben_ALTER_Monate";
            sheet.Cells[1, 21].Value = "Gestorben_ALTER_Tage";
            sheet.Cells[1, 22].Value = "Gestorbener_S";
            sheet.Cells[1, 23].Value = "Gestorbener_B";
            sheet.Cells[1, 24].Value = "Ehe_W";
            sheet.Cells[1, 25].Value = "Ehe_V";
            sheet.Cells[1, 26].Value = "Ehe_F";
            sheet.Cells[1, 27].Value = "Ehe_S";
            sheet.Cells[1, 28].Value = "Ehe_B";
            sheet.Cells[1, 29].Value = "Ehe_W";
            sheet.Cells[1, 30].Value = "Gestorbener_VATER_V";
            sheet.Cells[1, 31].Value = "Gestorbener_VATER_F";
            sheet.Cells[1, 32].Value = "Gestorbener_VATER_S";
            sheet.Cells[1, 33].Value = "Gestorbener_VATER_B";
            sheet.Cells[1, 34].Value = "Gestorbener_VATER_W";
            sheet.Cells[1, 35].Value = "Gestorbener_Mutter_V";
            sheet.Cells[1, 36].Value = "Gestorbener_Mutter_F";
            sheet.Cells[1, 37].Value = "Gestorbener_Mutter_S";
            sheet.Cells[1, 38].Value = "Beerdigungsort";
            sheet.Cells[1, 39].Value = "Todesursache";
            sheet.Cells[1, 40].Value = "Sonstiges";
            sheet.Cells[1, 41].Value = "URL";
            sheet.Cells[1, 42].Value = "Einsender";
            num = 2;
            using (FileStream filestream = new FileStream(inputFilename, FileMode.Open, FileAccess.Read))
            {
                using (StreamReader reader = new StreamReader(filestream, Encoding.Default))
                {
                    kronland = reader.ReadLine();
                    staat = reader.ReadLine();
                    buchtyp = reader.ReadLine();
                    ort = reader.ReadLine();
                    ortdetail = reader.ReadLine();
                    konfession = reader.ReadLine();
                    buch = reader.ReadLine();
                    genealogist = reader.ReadLine();
                    year = "";
                    isdp = "";
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        if (line.Length == 0)
                        {
                            continue;
                        }
                        if (line.Equals(" "))
                        {
                            continue;
                        }
                        if ((line.Length.Equals(4)) && (line.Contains("DP") == false))
                        {
                            year = line;
                            continue;
                        }
                        if (line.StartsWith("DP"))
                        {
                            line = line.Substring(3);
                            isdp = line;
                            continue;
                        }
                        sheet.Cells[num, 1].Value = kronland;
                        sheet.Cells[num, 2].Value = staat;
                        sheet.Cells[num, 3].Value = buchtyp;
                        sheet.Cells[num, 4].Value = ort;
                        sheet.Cells[num, 5].Value = ortdetail;
                        sheet.Cells[num, 6].Value = konfession;
                        sheet.Cells[num, 7].Value = buch;
                        sheet.Cells[num, 10].Value = year;
                        sheet.Cells[num, 9].Value = isdp;

                        int idx = line.IndexOf(".");
                        int idx2 = line.IndexOf(",");
                        if (idx < idx2)
                        {
                            line = "#," + line;
                        }

                        sheet.Cells[num, 8].Value = GetOrtSterbe(line);
                        sheet.Cells[num, 40].Value = Death.GetDeathComment(line);
                        sheet.Cells[num, 41].Value = Marriage.GetURL(line);
                        sheet.Cells[num, 42].Value = genealogist;
                        sheet.Cells[num, 11].Value = Common.GetMonat(line);
                        sheet.Cells[num, 12].Value = Common.GetTag(line);
                        sheet.Cells[num, 16].Value = Common.GetVorname(line);
                        sheet.Cells[num, 19].Value = Death.GetAgeYears(line);
                        sheet.Cells[num, 20].Value = Death.GetAgeMonths(line);
                        sheet.Cells[num, 21].Value = Death.GetAgeDays(line);
                        if ((line.Contains("(vidua")) || (line.Contains("(Witwe")) || (line.Contains("(Ehefrau")))
                        {
                            sheet.Cells[num, 25].Value = Common.GetVaterVorname(line);
                            sheet.Cells[num, 26].Value = Common.GetVaterNachname(line);
                        }
                        else
                        {
                            if (Common.GetVaterVorname(line).Equals("-"))
                            {
                                sheet.Cells[num, 17].Value = Common.GetVaterNachname(line);
                            }
                            else
                            {
                                sheet.Cells[num, 30].Value = Common.GetVaterVorname(line);
                                sheet.Cells[num, 31].Value = Common.GetVaterNachname(line);
                            }
                        }
                        if (line.Contains("(geboren "))
                        {
                            sheet.Cells[num, 30].Value = Death.GetVaterVorname2(line);
                            sheet.Cells[num, 31].Value = Death.GetVaterNachname2(line);
                        }
                        if ((line.Contains("(vidua")) || (line.Contains("(Witwe")) || (line.Contains("(Ehefrau")))
                        {
                            if (
                              (((string)Death.GetDeathBeruf(line)).EndsWith("in")) ||
                              (((string)Death.GetDeathBeruf(line)).Equals("Inweib")) ||
                              (((string)Death.GetDeathBeruf(line)).Equals("ledig")))
                            {
                                sheet.Cells[num, 23].Value = Death.GetDeathBeruf(line);
                            }
                            else
                            {
                                sheet.Cells[num, 28].Value = Death.GetDeathBeruf(line);
                            }

                        }
                        else
                        {
                            if (!Common.GetVaterVorname(line).Equals("-"))
                            {
                                sheet.Cells[num, 33].Value = Death.GetDeathBeruf(line);
                            }
                            else
                            {
                                if (Death.GetAgeYearsInt(line) < 18)
                                {
                                    sheet.Cells[num, 33].Value = Death.GetDeathBeruf(line);
                                }
                                else
                                {
                                    sheet.Cells[num, 23].Value = Death.GetDeathBeruf(line);
                                }

                            }
                        }
                        sheet.Cells[num, 35].Value = Death.GetMotherVorname(line);
                        sheet.Cells[num, 36].Value = Death.GetMotherNachname(line);

                        if (Marriage.ErrorString.Length == 0)
                        {
                            labStatusValue.Text = "Converting [" + num + "] ...";
                        }
                        else
                        {
                            labStatusValue.Text = Marriage.ErrorString;
                            break;
                        }
                        num++;
                    }


                }
            }
        }
    }
}
