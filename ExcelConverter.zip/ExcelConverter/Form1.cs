﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;

namespace ExcelConverter
{
    public partial class Form1 : Form
    {
        Excel.Application excelData;

        public Form1()
        {
            InitializeComponent();
            labStatus.Text = "Status:";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            if (txtOutput.Text.Length == 0) return;
            if (File.ReadAllText(txtFilename.Text) == null) return;

            Cursor.Current = Cursors.WaitCursor;
            Excel.Application xlApp = new Excel.Application();
            Excel.Workbook xlWorkbook = xlApp.Workbooks.Add();
            Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];
            Excel.Range xlRange = xlWorksheet.UsedRange;
            excelData = xlApp;

            Marriage.ErrorString = "";
            labStatusValue.Text = "Converting ...";
            bool isMarry = false;
            using (FileStream filestream = new FileStream(txtFilename.Text, FileMode.Open, FileAccess.Read))
            {
                using (StreamReader reader = new StreamReader(filestream, Encoding.Default))
                {
                    var line = reader.ReadLine();
                    line = reader.ReadLine();
                    line = reader.ReadLine();
                    if (line.Contains("Hochzeiten"))
                    {
                        reader.Close();
                        Marriage.DisplayInExcelMarry(excelData, txtFilename.Text, labStatusValue);
                        isMarry = true;
                    }
                    else
                    {
                        reader.Close();
                        isMarry = false;
                    }
                }
            }
            if (!isMarry)
            {
                using (FileStream filestream = new FileStream(txtFilename.Text, FileMode.Open, FileAccess.Read))
                {
                    using (StreamReader reader = new StreamReader(filestream, Encoding.Default))
                    {
                        var line = reader.ReadLine();
                        line = reader.ReadLine();
                        line = reader.ReadLine();
                        if (line.Contains("Sterbedaten"))
                        {
                            reader.Close();
                            Death.DisplayInExcelSterbe(excelData, txtFilename.Text, labStatusValue);
                            isMarry = true;
                        }
                        else
                        {
                            reader.Close();
                            isMarry = false;
                        }
                    }
                }
            }
            if (!isMarry)
            {
               
                Baptism.DisplayInExcelBaptisms(excelData, txtFilename.Text, labStatusValue);
            }
            if (Marriage.ErrorString != "") labStatusValue.Text = Marriage.ErrorString;
            else labStatusValue.Text = "Conversion Finished";
            xlApp.Visible = false;
            xlApp.UserControl = false;
            //xlWorkbook.Set
            //xlWorkbook.Save();
            xlWorkbook.SaveCopyAs(txtOutput.Text);


            //cleanup
            GC.Collect();
            GC.WaitForPendingFinalizers();

            //close and release
            try
            {
                xlWorkbook.Close();
            }
            catch(Exception)
            {

            }
            try
            {
                Marshal.ReleaseComObject(xlWorkbook);
                Marshal.ReleaseComObject(xlRange);
            }
            catch(Exception)
            {

            }
            //quit and release
            try
            {
                xlApp.Quit();
            }
            catch(Exception)
            {

            }
            try
            {
                Marshal.ReleaseComObject(xlApp);
            }
            catch(Exception)
            {

            }
                // Set cursor as default arrow
                Cursor.Current = Cursors.Default;
        }
    }
}
